import csv
import numpy as np
import os
import math
import random
import copy
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
import threading
import time
import matplotlib.pyplot as plt
from scipy.io import loadmat
from collections import Counter
from scipy.ndimage import gaussian_filter

# 全局地图大小
Map_size = 30

def softsign(x):
	softsign = x / (1 + np.abs(x))
	return softsign


# 缓存任务位置的版本
def calculate_dynamic_avg_dist_cached(source_pos, task_locations_cache):
	"""
	【缓存版本】使用预计算的任务位置计算平均距离。

	参数:
	  source_pos (tuple): 源位置 (x, y)
	  task_locations_cache (ndarray): 预计算的任务位置数组，shape (N, 2)

	返回:
	  float: 平均欧几里得距离。如果没有任务，则返回0。
	"""
	if task_locations_cache.shape[0] == 0:
		return 0.0

	# 使用NumPy的广播机制进行向量化计算
	diff = task_locations_cache - np.array(source_pos)
	squared_diff = np.square(diff)
	sum_squared_diff = np.sum(squared_diff, axis=1)
	distances = np.sqrt(sum_squared_diff)

	return np.mean(distances)

def distance(a, b):
	"""
	快速二维欧几里得距离计算
	参数 a,b: (x,y) 元组或列表
	"""
	return math.hypot(a[0] - b[0], a[1] - b[1])


def softmax(x):
	"""Softmax函数，将得分转换为选择概率"""
	e_x = np.exp(x - np.max(x))  # 防止溢出
	return e_x / e_x.sum(axis=0)


def _read_csv_dicts(filename):
	"""以字典列表方式读取 CSV 文件"""
	with open(filename, mode='r', newline='') as f:
		reader = csv.DictReader(f)
		return list(reader)


def read_data(map_size=None, file_prefix=''):
	"""
	读取所有场景数据文件，构造环境与智能体列表。

	参数:
	  map_size: 可选, 地图边长. 如果为 None, 将根据所有实体的最大坐标动态推断.
	  file_prefix: 可选, CSV 文件的路径前缀.

	返回:
	  Env: ndarray, shape (2, map_size, map_size), 0=卸载/停靠点, 1=任务点
	  task_data: ndarray, shape (map_size, map_size), 任务耗时矩阵, 0=无任务
	  Curr_Agents: list of [date, uptime, x, y, downtime, type, speed, memory, full_memory]
	"""
	# 文件路径
	uav_file = os.path.join(file_prefix, './Data/uavMap.csv')
	worker_file = os.path.join(file_prefix, './Data/workerMap.csv')
	server_file = os.path.join(file_prefix, './Data/serverMap.csv')
	comm_file = os.path.join(file_prefix, './Data/commMap.csv')
	task_file = os.path.join(file_prefix, './Data/taskMap.csv')
	stop_file = os.path.join(file_prefix, './Data/stopMap.csv')

	# 读取 CSV
	uav_list = _read_csv_dicts(uav_file)
	worker_list = _read_csv_dicts(worker_file)
	server_list = _read_csv_dicts(server_file)
	comm_list = _read_csv_dicts(comm_file)
	task_list = _read_csv_dicts(task_file)
	stop_list = _read_csv_dicts(stop_file)

	# 动态推断地图大小
	if map_size is None:
		xs, ys = [], []
		for L in [uav_list, worker_list, server_list, comm_list, task_list, stop_list]:
			for d in L:
				xs.append(int(d['x']))
				ys.append(int(d['y']))
		map_size = max(max(xs), max(ys)) + 1

	# 初始化环境
	Env = np.zeros((2, map_size, map_size), dtype=int)
	task_data = np.zeros((map_size, map_size), dtype=float)
	global_task_matrix = np.zeros((map_size, map_size), dtype=int)  # 新增全局任务矩阵

	# 填充任务点
	for row in task_list:
		x, y = int(row['x']), int(row['y'])
		Env[1, x, y] = 1
		task_data[x, y] = float(row['T_datasize'])
		global_task_matrix[x, y] = 1  # 标记为存在任务

	# 填充卸载/停靠点
	for row in stop_list:
		x, y = int(row['x']), int(row['y'])
		Env[0, x, y] = 1

	# 构造统一的智能体列表
	# 先收集停靠点位置，判断通信汽车初始是否能提供通信
	stop_positions = {(int(r['x']), int(r['y'])) for r in stop_list}

	Agents_list = []  # [ uptime, downtime, x, y, type, speed, memory, full_memory]
	id = 0
	is_over_downtime = 0.0
	# 工人 (type=1)，无内存字段
	for row in worker_list:
		Agents_list.append([
			int(id),
			int(row['W_uptime']),
			int(row['x']),
			int(row['y']),
			int(row['W_downtime']),
			1,
			float(row['workerRge']),
			0.0,
			0.0,
			is_over_downtime,
			-1,  # target_x
			-1,  # target_y
			0  # move_remaining
		])
		id += 1
	# 移动服务器 (type=2)，内存字段不使用，full_memory存数据吞吐率
	for row in server_list:
		Agents_list.append([
			int(id),
			int(row['S_uptime']),
			int(row['x']),
			int(row['y']),
			int(row['S_downtime']),
			2,
			float(row['serverRge']),
			0.0,
			float(row['S_throughput']),
			is_over_downtime,
			-1,  # target_x
			-1,  # target_y
			0  # move_remaining
		])
		id += 1
	# 感知无人机 (type=3)
	for row in uav_list:
		Agents_list.append([
			int(id),
			int(row['U_uptime']),
			int(row['x']),
			int(row['y']),
			int(row['U_downtime']),
			3,
			float(row['uavRge']),
			float(row['uMemory']),
			float(row['Fullmemory']),
			is_over_downtime,
			-1,  # target_x
			-1,  # target_y
			0  # move_remaining
		])
		id += 1
	# 通信汽车 (type=4)，无内存字段
	for row in comm_list:
		x, y = int(row['x']), int(row['y'])
		can_comm = 1 if (x, y) in stop_positions else 0
		Agents_list.append([
			int(id),
			int(row['Com_uptime']),
			int(row['x']),
			int(row['y']),
			int(row['Com_downtime']),
			4,
			float(row['commRge']),
			0.0,
			can_comm,
			is_over_downtime,
			-1,  # target_x
			-1,  # target_y
			0  # move_remaining
		])
		id += 1

	return uav_list, worker_list, server_list, comm_list, Agents_list, Env, task_data, stop_positions, global_task_matrix

# 通信车记忆矩阵管理类
class CommCarMemoryManager:
	def __init__(self, map_size, global_task_matrix):
		self.map_size = map_size
		self.comm_memory = {}  # 通信车ID -> 记忆矩阵
		self.agent_visible_tasks = {}  # 智能体ID -> 可见任务矩阵
		self.global_task_matrix = global_task_matrix  # 存储全局任务矩阵
		self.comm_groups = {}  # 通信组字典：group_id -> CommGroup对象
		self.agent_task_locations_cache = {}  # 智能体ID -> 任务位置数组
		self.agent_avg_dist_cache = {}  # 智能体ID -> {位置: 平均距离}

	def init_comm_memory(self, comm_cars, Env):
		"""初始化通信车记忆矩阵为全局任务点分布"""
		for car in comm_cars:
			car_id = car[0]
			# 初始记忆为全局任务矩阵的副本
			self.comm_memory[car_id] = self.global_task_matrix.copy()

	def update_comm_memory_from_reality(self, comm_car, Env, radius):
		"""根据当前位置更新通信车记忆矩阵（仅限通信范围内）"""
		car_id = comm_car[0]
		x, y = comm_car[2], comm_car[3]
		memory = self.comm_memory[car_id]

		# 更新通信范围内的任务点
		for i in range(max(0, int(x - radius)), min(int(self.map_size), int(x + radius + 1))):
			for j in range(max(0, int(y - radius)), min(int(self.map_size), int(y + radius + 1))):
				if distance([x, y], [i, j]) <= radius:
					# 用真实环境更新记忆
					memory[i, j] = Env[1, i, j]

	def share_comm_memory(self, comm_cars, radius):
		"""通信车之间共享记忆矩阵（互相覆盖时）"""
		# 找出互相覆盖的通信车组
		groups = []
		visited = set()
		for i, car1 in enumerate(comm_cars):
			if i in visited:
				continue
			group = [car1[0]]
			queue = [i]
			visited.add(i)
			while queue:
				idx = queue.pop(0)
				for j, car2 in enumerate(comm_cars):
					if j not in visited and distance(car1[2:4], car2[2:4]) <= radius:
						visited.add(j)
						queue.append(j)
						group.append(car2[0])
			groups.append(group)

		# 合并每个组内的记忆（取交集：有0即0）
		for group in groups:
			if len(group) == 0:
				continue

			# 初始化合并后的记忆（全1）
			merged_memory = np.ones((self.map_size, self.map_size))

			# 取交集：只要有一个通信车记忆为0，则该点为0
			for car_id in group:
				merged_memory = np.minimum(merged_memory, self.comm_memory[car_id])

			# 更新组内所有通信车的记忆
			for car_id in group:
				self.comm_memory[car_id] = merged_memory.copy()

	def update_agent_visible_tasks(self, agents, comm_cars, radius):
		"""更新每个智能体的可见任务矩阵（覆盖它的通信车记忆的并集）"""
		self.agent_visible_tasks = {}
		self.agent_task_locations_cache = {}  # 清空任务位置缓存
		self.agent_avg_dist_cache = {}  # 清空距离缓存

		for agent in agents:
			agent_id = agent[0]
			agent_x, agent_y = agent[2], agent[3]

			# 初始化可见任务矩阵（全0）
			visible_tasks = np.zeros((self.map_size, self.map_size))

			# 找出覆盖该智能体的所有通信车
			for car in comm_cars:
				if distance([agent_x, agent_y], car[2:4]) <= radius:
					# 取并集：只要有一个通信车记忆为1，则该点可见
					visible_tasks = np.maximum(visible_tasks, self.comm_memory[car[0]])

			self.agent_visible_tasks[agent_id] = visible_tasks

			# 预计算并缓存任务位置
			task_locations = np.argwhere(visible_tasks == 1)
			self.agent_task_locations_cache[agent_id] = task_locations

			# 初始化距离缓存字典
			self.agent_avg_dist_cache[agent_id] = {}

	def get_cached_avg_distance(self, agent_id, position):
		"""获取缓存的平均距离，如果不存在则计算并缓存"""
		pos_key = tuple(position)

		if agent_id not in self.agent_avg_dist_cache:
			self.agent_avg_dist_cache[agent_id] = {}

		if pos_key not in self.agent_avg_dist_cache[agent_id]:
			# 计算并缓存
			task_locations = self.agent_task_locations_cache.get(agent_id, np.array([]).reshape(0, 2))
			avg_dist = calculate_dynamic_avg_dist_cached(position, task_locations)
			self.agent_avg_dist_cache[agent_id][pos_key] = avg_dist

		return self.agent_avg_dist_cache[agent_id][pos_key]

# 考虑停靠点，扩散任务点
def comm_car_reward(comm_car, stop_point, memory_manager, radius,
					task_weight=1, stop_weight=1, sigma=2):
	"""
	计算通信车在特定停靠点时的综合收益：
	- 任务覆盖（高斯扩散平滑）
	- 停靠点覆盖（促进 UAV 卸载）
	"""
	car_id = comm_car[0]
	memory = memory_manager.comm_memory[car_id]
	x, y = int(stop_point[0]), int(stop_point[1])

	# ===== 任务覆盖收益（保留原高斯扩散）=====
	# ===== 任务覆盖收益（保留原高斯扩散）=====
	smoothed_matrix = gaussian_filter(memory, sigma=sigma)
	task_cover_reward = 0
	for i in range(max(0, x - radius), min(Map_size, x + radius + 1)):
		for j in range(max(0, y - radius), min(Map_size, y + radius + 1)):
			if distance([x, y], [i, j]) <= radius:
				task_cover_reward += smoothed_matrix[i, j]

	# ===== 停靠点覆盖收益 =====
	stop_cover_reward = 0
	for stop_x, stop_y in stop_positions:
		dist_to_stop = distance([x, y], [stop_x, stop_y])
		if dist_to_stop <= radius:
			stop_cover_reward += 1

	# ===== 综合收益 =====
	cover_reward = task_weight * task_cover_reward + stop_weight * stop_cover_reward

	return cover_reward

# # 考虑停靠点，任务点停靠点都扩散
# def comm_car_reward(comm_car, stop_point, memory_manager, radius,
# 					task_weight=1, stop_weight=1, sigma=2):
# 	"""
# 	计算通信车在特定停靠点时的综合收益：
# 	- 任务覆盖（高斯扩散平滑）
# 	- 停靠点覆盖（高斯扩散平滑）
# 	"""
# 	car_id = comm_car[0]
# 	memory = memory_manager.comm_memory[car_id]  # 任务矩阵
# 	x, y = int(stop_point[0]), int(stop_point[1])
#
# 	# ===== 任务覆盖收益 =====
# 	smoothed_task_matrix = gaussian_filter(memory, sigma=sigma)
# 	task_cover_reward = 0
# 	for i in range(max(0, x - radius), min(Map_size, x + radius + 1)):
# 		for j in range(max(0, y - radius), min(Map_size, y + radius + 1)):
# 			if distance([x, y], [i, j]) <= radius:
# 				task_cover_reward += smoothed_task_matrix[i, j]
#
# 	# ===== 停靠点覆盖收益（新增高斯平滑） =====
# 	# 构造停靠点矩阵
# 	stop_matrix = np.zeros((Map_size, Map_size))
# 	for sx, sy in stop_positions:
# 		stop_matrix[sx, sy] = 1
#
# 	smoothed_stop_matrix = gaussian_filter(stop_matrix, sigma=sigma)
# 	stop_cover_reward = 0
# 	for i in range(max(0, x - radius), min(Map_size, x + radius + 1)):
# 		for j in range(max(0, y - radius), min(Map_size, y + radius + 1)):
# 			if distance([x, y], [i, j]) <= radius:
# 				stop_cover_reward += smoothed_stop_matrix[i, j]
#
# 	# ===== 综合收益 =====
# 	cover_reward = task_weight * task_cover_reward + stop_weight * stop_cover_reward
#
# 	return cover_reward


# 更新通信范围矩阵
def update_communication_matrices(Curr_Agents, Curr_Com, radius, Row, Lin):
	"""更新所有智能体的通信范围矩阵"""
	# 1. 找出互相覆盖的通信车组
	comm_groups = []  # 存储通信车组的列表
	visited = set()  # 已访问的通信车索引

	# 使用BFS找出所有互相覆盖的通信车组
	for i, car1 in enumerate(Curr_Com):
		if i in visited:
			continue
		group = [car1[0]]  # 当前组包含的通信车ID
		queue = [i]  # BFS队列
		visited.add(i)
		while queue:
			idx = queue.pop(0)
			curr_car = Curr_Com[idx]
			for j, other_car in enumerate(Curr_Com):
				if j not in visited:
					# 计算两车距离
					dist = distance(curr_car[2:4], other_car[2:4])
					if dist <= radius:  # 在通信范围内
						visited.add(j)
						queue.append(j)
						group.append(other_car[0])
		comm_groups.append(group)

	# 2. 为每个通信车组创建合并后的通信矩阵
	group_matrices = {}
	for group in comm_groups:
		merged_matrix = np.zeros((Row, Lin))
		for car_id in group:
			# 找到该通信车
			car = next(c for c in Curr_Com if c[0] == car_id)
			x, y = car[2], car[3]
			# 标记该通信车的覆盖范围
			for i in range(Row):
				for j in range(Lin):
					if distance([x, y], [i, j]) <= radius:
						merged_matrix[i, j] = 1
		group_matrices[tuple(group)] = merged_matrix

	# 3. 创建每个通信车的通信矩阵（使用组矩阵）
	all_com = []
	for car in Curr_Com:
		car_id = car[0]
		# 找到该通信车所属的组
		for group, matrix in group_matrices.items():
			if car_id in group:
				all_com.append(matrix.copy())
				break
		else:
			# 如果没有找到组，使用自己的通信范围
			self_matrix = np.zeros((Row, Lin))
			x, y = car[2], car[3]
			for i in range(Row):
				for j in range(Lin):
					if distance([x, y], [i, j]) <= radius:
						self_matrix[i, j] = 1
			all_com.append(self_matrix)

	# 4. 创建每个智能体的通信矩阵
	all_connet = []
	for agent in Curr_Agents:
		agent_matrix = np.zeros((Row, Lin))
		agent_x, agent_y = agent[2], agent[3]

		# 找出覆盖该智能体的通信车组
		covered_groups = set()
		for car in Curr_Com:
			car_x, car_y = car[2], car[3]
			if distance([agent_x, agent_y], [car_x, car_y]) <= radius:
				# 找到该通信车所属的组
				for group in group_matrices:
					if car[0] in group:
						covered_groups.add(group)
						break

		# 合并所有覆盖该智能体的组的通信矩阵
		for group in covered_groups:
			agent_matrix = np.maximum(agent_matrix, group_matrices[group])

		all_connet.append(agent_matrix)

	return all_connet, all_com

def get_final_actions(Curr_Agents, all_behavior, all_connet, Env_Train, task_data,
					  SysTime, SingleStep, TimeLimit, Env, memory_manager,
					  max_iterations=10, improvement_threshold=1e-6):

	actions = [None] * len(Curr_Agents)

	for idx, agent in enumerate(Curr_Agents):
		agent_type = agent[5]
		avail_behavior = all_behavior[idx]
		avail_pos = [(x, y) for x in range(avail_behavior.shape[0])
					 for y in range(avail_behavior.shape[1]) if avail_behavior[x, y] == 1]

		# 通信车：行为由 schedule_comm_cars 确定
		if agent_type == 4:
			if avail_pos:
				actions[idx] = avail_pos[0]
			else:
				actions[idx] = (agent[2], agent[3])
			continue

		# 如果没有可选位置，保持原地
		if not avail_pos:
			actions[idx] = (agent[2], agent[3])
			continue

		# 工人 → 最近任务点
		if agent_type == 1:
			task_pos = [(x, y) for (x, y) in avail_pos if Env_Train[1, x, y] == 1]
			if task_pos:
				actions[idx] = min(task_pos, key=lambda pos: distance(pos, (agent[2], agent[3])))
			else:
				actions[idx] = (agent[2], agent[3])

		# 服务器 → 最近停靠点
		elif agent_type == 2:
			stop_pos = [(x, y) for (x, y) in avail_pos if Env_Train[0, x, y] == 1]
			if stop_pos:
				actions[idx] = min(stop_pos, key=lambda pos: distance(pos, (agent[2], agent[3])))
			else:
				actions[idx] = (agent[2], agent[3])

		# 无人机 → 最近任务点或停靠点
		elif agent_type == 3:
			# 获取智能体的可见任务矩阵
			agent_id = agent[0]
			visible_tasks = memory_manager.agent_visible_tasks.get(agent_id, np.zeros_like(Env_Train[1]))
			# 找出所有可行的任务点
			task_pos = [pos for pos in avail_pos if visible_tasks[int(pos[0]), int(pos[1])] == 1]
			stop_pos = []
			# 内存检查
			if agent[7] < agent[8]:
				stop_pos = [pos for pos in avail_pos if Env_Train[0, int(pos[0]), int(pos[1])] == 1]
			# 合并所有潜在目标点
			potential_targets = task_pos + stop_pos
			# 从所有潜在目标点中选择最近的一个
			if potential_targets:
				min_dist = float('inf')
				min_pos = None
				for pos in potential_targets:
					dist = distance(pos, [agent[2], agent[3]])
					if dist < min_dist:
						min_dist = dist
						min_pos = pos
				actions[idx] = min_pos
			# 如果没有可行的目标点，则保持原地
			if actions[idx] is None:
				actions[idx] = (agent[2], agent[3])


	# 贪心策略：不做多轮迭代优化，直接返回
	return actions, 1

def schedule_comm_cars(comm_cars, memory_manager, radius, SingleStep):

	# 使用字典来存储已确定的车辆行动，key为车辆ID，value为目标位置
	comm_actions_dict = {}

	# 按通信车ID排序，以确保决策顺序的确定性
	comm_cars_sorted = sorted(comm_cars, key=lambda x: x[0])

	for comm_car in comm_cars_sorted:
		best_adjusted_reward = -1
		best_stop = None
		current_pos = (comm_car[2], comm_car[3])
		car_id = comm_car[0]

		# 获取该车在一个步长时间内可以到达的停靠点
		available_stops = []
		for stop in stop_positions:
			dist = distance(current_pos, stop)
			move_time = dist / comm_car[6]
			if move_time <= SingleStep:
				available_stops.append(stop)

		# 如果没有可达的停靠点，将当前位置作为唯一选择，即保持原地
		if not available_stops:
			available_stops.append(current_pos)

		# 评估每一个可行的停靠点
		for stop in available_stops:
			# 1. 计算该车到这个停靠点的原始收益
			base_reward = comm_car_reward(comm_car, stop, memory_manager, radius)

			# 2. 统计已经做出决策的其他车辆中，有多少也选择了这个停靠点
			n_others_at_stop = 0
			for other_car_id, chosen_stop in comm_actions_dict.items():
				if chosen_stop == stop:
					n_others_at_stop += 1

			# 3. 计算如果当前车辆也选择这里，总共将有多少车辆
			n_total_at_stop = n_others_at_stop + 1

			# 4. 根据您的要求，调整收益
			adjusted_reward = base_reward / n_total_at_stop

			# 5. 选择能带来最大“调整后收益”的停靠点
			# 如果调整后收益更高，则更新最佳选择
			if adjusted_reward > best_adjusted_reward:
				best_adjusted_reward = adjusted_reward
				best_stop = stop
			# 如果收益相等，则优先选择距离更近的停靠点
			elif adjusted_reward == best_adjusted_reward:
				if best_stop is None or distance(current_pos, stop) < distance(current_pos, best_stop):
					best_stop = stop

		# 为当前车辆记录下最终决策
		# 如果经过评估仍然没有找到最佳点（理论上不会，因为至少有当前位置），则保持原地
		if best_stop is None:
			comm_actions_dict[car_id] = current_pos
		else:
			comm_actions_dict[car_id] = best_stop

	# 将决策字典转换回列表，并确保其顺序与函数输入的comm_cars列表一致
	final_actions_list = [comm_actions_dict[car[0]] for car in comm_cars]

	return final_actions_list


def update_comm_car_positions(comm_cars, comm_actions, stop_positions):
	"""更新通信车位置，并设置通信能力状态"""
	for i, car in enumerate(comm_cars):
		new_pos = comm_actions[i]
		# 更新位置
		car[2] = new_pos[0]  # x坐标
		car[3] = new_pos[1]  # y坐标

		# 清除目标位置和移动剩余时间
		car[10] = -1
		car[11] = -1
		car[12] = 0

		# 更新通信能力：如果新位置在停靠点上，则can_comm=1，否则为0
		if (new_pos[0], new_pos[1]) in stop_positions:
			car[8] = 1  # 可以通信
		else:
			car[8] = 0  # 不能通信


def update_environment(Env, Curr_Agents, actions, SingleStep, task_data, SystemTime, memory_manager, Curr_Com, radius):

	Row, Lin = Env.shape[1], Env.shape[2]
	N = len(Curr_Agents)

	# 初始化新位置矩阵、时间消耗、奖励
	DelatTime = np.zeros(N, dtype=int)
	Agent_Loc = np.zeros((N, Row, Lin), dtype=int)

	# 记录每个agent移动前的位置
	prev_positions = [(agent[2], agent[3]) for agent in Curr_Agents]

	# 更新位置与内存
	for i, agent in enumerate(Curr_Agents):
		action = actions[i]
		if action is None:
			continue

		x_new, y_new = action

		# 记录移动前的旧位置
		x0, y0 = agent[2], agent[3]

		agent[2] = x_new
		agent[3] = y_new

		# 1. 标记新位置
		Agent_Loc[i, int(x_new), int(y_new)] = 1
		# 2. 计算移动距离与耗时 (使用修正前记录的 x0, y0)
		dist = distance([x0, y0], [x_new, y_new])
		time_cost = math.ceil(dist / agent[6])
		DelatTime[i] = time_cost

	offloaded_data = 0
	finish_task = 0

	# 更新任务与卸载、计算奖励
	for x in range(Row):
		for y in range(Lin):
			# 统计各类型数量
			workers = []
			servers = []
			uavs = []
			coms = []
			for i, agent in enumerate(Curr_Agents):
				# if Agent_Loc[i, x, y] == 1 and DelatTime[i] <= SingleStep:
				if Agent_Loc[i, x, y] == 1:
					t = agent[5]
					if t == 1:
						workers.append(i)
					elif t == 2:
						servers.append(i)
					elif t == 3:
						uavs.append(i)
					elif t == 4:
						coms.append(i)
			# 任务完成
			if Env[1, x, y] == 1 and workers and uavs:
				Env[1, x, y] = 0
				finish_task += 1

				# 找出覆盖了参与该任务的智能体的通信车
				covered_comm_cars = set()

				# 检查所有参与任务的工人
				for w_idx in workers:
					worker = Curr_Agents[w_idx]
					worker_pos = (worker[2], worker[3])

					# 找出覆盖该工人的通信车
					for comm_car in Curr_Com:
						if distance(worker_pos, (comm_car[2], comm_car[3])) <= radius:
							covered_comm_cars.add(comm_car[0])

				# 检查所有参与任务的无人机
				for u_idx in uavs:
					uav = Curr_Agents[u_idx]
					uav_pos = (uav[2], uav[3])

					# 找出覆盖该无人机的通信车
					for comm_car in Curr_Com:
						if distance(uav_pos, (comm_car[2], comm_car[3])) <= radius:
							covered_comm_cars.add(comm_car[0])

				# 更新覆盖了参与任务的智能体的通信车的记忆矩阵
				for car_id in covered_comm_cars:
					memory_manager.comm_memory[car_id][x, y] = 0  # 标记任务已完成

				# 取最早到达的用户和 UAV
				t_worker = min((DelatTime[i], i) for i in workers)
				t_uav = min((DelatTime[i], i) for i in uavs)
				# 完成任务需要内存
				cost = task_data[x, y]
				# 到达位置的最晚时间+任务完成时间
				end_time = max(t_worker[0], t_uav[0]) + math.ceil(cost / Curr_Agents[t_uav[1]][6])
				DelatTime[t_worker[1]] = end_time
				DelatTime[t_uav[1]] = end_time
				# UAV 内存变化
				Curr_Agents[t_uav[1]][7] = Curr_Agents[t_uav[1]][7] - cost

				# 打印任务完成事件
				uav_task = Curr_Agents[t_uav[1]]
				worker_task = Curr_Agents[t_worker[1]]
				uav_prev_x, uav_prev_y = prev_positions[t_uav[1]]
				worker_prev_x, worker_prev_y = prev_positions[t_worker[1]]
				print(f"[TASK_SUCCESS] "
					  f"uav= id:{uav_task[0]},从({uav_prev_x},{uav_prev_y})到({x},{y}) 和 "
					  f"worker=id:{worker_task[0]},从({worker_prev_x},{worker_prev_y})到({x},{y}) "
					  f"完成任务，完成时刻为：{SystemTime + end_time},uav_remain_memory={uav_task[7]:.1f}")

			elif Env[1, x, y] == 1 and (workers and not uavs or uavs and not workers):
				# 有人来但没人配
				for u in uavs:
					uav_no_task = Curr_Agents[u]
					uav_prev_x, uav_prev_y = prev_positions[u]
					print(f"[TASK_FAIL] "
						  f"uav = id:{uav_no_task[0]},从({uav_prev_x},{uav_prev_y})"
						  f"要去 task = {(x, y)}, 但是没有 worker来这个任务点,uav_remain_memory={uav_no_task[7]} ")
				for w in workers:
					worker_no_task = Curr_Agents[w]
					worker_prev_x, worker_prev_y = prev_positions[w]
					print(f"[TASK_FAIL] "
						  f"worker= id:{worker_no_task[0]},从({worker_prev_x},{worker_prev_y})"
						  f"要去 task= {(x, y)}, 但是没有 uav来这个任务点 ")

			# 卸载
			if Env[0, x, y] == 1 and servers and uavs:
				# 1. 找最早到达的移动服务器
				t_server = min((DelatTime[i], i) for i in servers)
				server_time = DelatTime[t_server[1]]

				# 2. 排序 UAV 到达时间，排队来
				uavs_sorted = sorted([(DelatTime[i], i) for i in uavs])
				for t_arrival, uav_i in uavs_sorted:

					if Curr_Agents[uav_i][7] >= Curr_Agents[uav_i][8]:
						continue

					# 开始时间是：无人机到 or 上一个 UAV 卸载完之后
					start = max(server_time, t_arrival)
					needed = Curr_Agents[uav_i][8] - Curr_Agents[uav_i][7]
					rate = Curr_Agents[t_server[1]][8]
					offload_time = math.ceil(needed / rate)
					end_time = start + offload_time

					# 更新时间和内存
					offloaded_data += needed
					Curr_Agents[uav_i][7] = Curr_Agents[uav_i][8]  # 满内存
					DelatTime[uav_i] = end_time

					# 更新车辆的服务时间（下一架 UAV 要等它）
					server_time = end_time
					DelatTime[t_server[1]] = server_time  # 车也在等最后一架 UAV

					# ... 成功逻辑 ...
					server_prev_x, server_prev_y = prev_positions[t_server[1]]
					uav_prev_x, uav_prev_y = prev_positions[uav_i]
					print(f"[Offload_SUCCESS] "
						  f"server = id:{Curr_Agents[t_server[1]][0]},从({server_prev_x},{server_prev_y})到({x},{y})和  "
						  f"uav =id:{Curr_Agents[uav_i][0]},从({uav_prev_x},{uav_prev_y})到({x},{y}) "
						  f"完成卸载，完成时刻为:{SystemTime + end_time}, uav_remain_memory={Curr_Agents[uav_i][7]:.1f}")

			elif Env[0, x, y] == 1 and (servers and not uavs or uavs and not servers):
				# 有无人机没服务器
				for u in uavs:
					uav_no_offload = Curr_Agents[u]
					uav_prev_x, uav_prev_y = prev_positions[u]
					print(f"[Offload_FAIL] "
						  f"uav = id:{uav_no_offload[0]},从({uav_prev_x},{uav_prev_y})"
						  f"要去 stop = {(x, y)}, 但是没有 server 来这个停靠点, uav_remain_memory={uav_no_offload[7]} ")
				for s in servers:
					server_no_offload = Curr_Agents[s]
					server_prev_x, server_prev_y = prev_positions[s]
					print(f"[Offload_FAIL] "
						  f"server= id:{server_no_offload[0]},从({server_prev_x},{server_prev_y})"
						  f"要去 stop = {(x, y)}, 但是没有 uav来这个停靠点 ")

	return Env, Curr_Agents, DelatTime, finish_task, offloaded_data


def get_behavior(Curr_Agents, Curr_Com, radius, Env_Train, task_data, SingleStep, SysTime, TimeLimit, Env,
				 memory_manager, max_iter, comm_actions_dict=None):
	Row, Lin = Env_Train.shape[1], Env_Train.shape[2]

	# 更新通信范围矩阵
	all_connet, all_com = update_communication_matrices(Curr_Agents, Curr_Com, radius, Row, Lin)

	# 构建行为空间
	all_behavior = []
	for i, agent in enumerate(Curr_Agents):
		avail_behavior = np.zeros((Row, Lin))
		agent_type = agent[5]
		agent_pos = (agent[2], agent[3])  # 当前坐标

		# 如果是通信车，使用预设动作
		if agent_type == 4 and comm_actions_dict is not None and agent[0] in comm_actions_dict:
			x, y = comm_actions_dict[agent[0]]
			avail_behavior[int(x), int(y)] = 1
			all_behavior.append(avail_behavior)
			continue

		# 获取智能体的可见任务矩阵
		agent_id = agent[0]
		visible_tasks = memory_manager.agent_visible_tasks.get(agent_id, np.zeros_like(Env_Train[1]))

		# 工人
		if agent_type == 1:
			for Dim_Row in range(Row):
				for Dim_Lin in range(Lin):
					if visible_tasks[Dim_Row, Dim_Lin] == 1 and distance(agent_pos, (Dim_Row, Dim_Lin)) <= radius:
						avail_behavior[Dim_Row, Dim_Lin] = 1
			if np.all(avail_behavior == 0):
				avail_behavior[int(agent[2]), int(agent[3])] = 1

		# 移动服务器
		elif agent_type == 2:
			for Dim_Row in range(Row):
				for Dim_Lin in range(Lin):
					if Env_Train[0, Dim_Row, Dim_Lin] == 1 and distance(agent_pos, (Dim_Row, Dim_Lin)) <= radius:
						avail_behavior[Dim_Row, Dim_Lin] = 1
			if np.all(avail_behavior == 0):
				avail_behavior[int(agent[2]), int(agent[3])] = 1

		# 感知无人机
		elif agent_type == 3:
			remaining_time = agent[4] - SysTime  # 剩余在线时间
			# 计算到最近停靠点的最短时间
			min_stop_dist = min(distance(agent_pos, stop) for stop in stop_positions)
			min_stop_time = min_stop_dist / agent[6]
			# 计算最大卸载时间
			if any(s[5] == 2 for s in Curr_Agents):
				min_server_rate = min(s[8] for s in Curr_Agents if s[5] == 2)
			else:
				min_server_rate = 1e-6
			unload_time = max(0, (agent[8] - agent[7]) / min_server_rate)

			if remaining_time <= min_stop_time + unload_time + SingleStep:
				# 只保留停靠点
				avail_behavior = np.zeros((Row, Lin))
				for stop in stop_positions:
					if distance(agent_pos, stop) <= radius:
						avail_behavior[stop[0], stop[1]] = 1
				if np.all(avail_behavior == 0):
					avail_behavior[int(agent[2]), int(agent[3])] = 1
				all_behavior.append(avail_behavior)
				continue

			# 任务点
			for Dim_Row in range(Row):
				for Dim_Lin in range(Lin):
					if visible_tasks[Dim_Row, Dim_Lin] == 1 and distance(agent_pos, (Dim_Row, Dim_Lin)) <= radius:
						if task_data[Dim_Row, Dim_Lin] <= agent[7]:
							move_time_to_task = distance(agent_pos, (Dim_Row, Dim_Lin)) / agent[6]
							task_execution_time = task_data[Dim_Row, Dim_Lin] / agent[6]
							min_distance_to_stop = float('inf')
							for stop in stop_positions:
								dist = distance((Dim_Row, Dim_Lin), stop)
								if dist < min_distance_to_stop:
									min_distance_to_stop = dist
							move_time_to_stop = min_distance_to_stop / agent[6]
							total_time = move_time_to_task + task_execution_time + move_time_to_stop
							if total_time <= remaining_time:
								avail_behavior[Dim_Row, Dim_Lin] = 1

			# 停靠点
			for Dim_Row in range(Row):
				for Dim_Lin in range(Lin):
					if Env_Train[0, Dim_Row, Dim_Lin] == 1 and distance(agent_pos, (Dim_Row, Dim_Lin)) <= radius:
						if agent[7] < agent[8]:
							avail_behavior[Dim_Row, Dim_Lin] = 1

			if np.all(avail_behavior == 0):
				avail_behavior[int(agent[2]), int(agent[3])] = 1

		all_behavior.append(avail_behavior)

	# 获取最终动作
	actions, count = get_final_actions(Curr_Agents, all_behavior, all_connet, Env_Train, task_data,
									   SysTime, SingleStep, TimeLimit, Env, memory_manager)
	return actions, count



if __name__ == '__main__':
	max_result = 0.0
	min_result = 1.0
	TimeLimit = 240  # 总时长
	SingleStep = 5  # 步长
	Map_size = 40  # 地图大小
	radius = 8  # 通信范围
	uav_list, worker_list, server_list, com_list, Agents_list, Env, task_data, stop_positions, global_task_matrix = read_data(
		Map_size)

	# =====================距离期望值的预计算=====================
	# 获取所有任务点和停靠点的位置 - 使用实际的 Env 数组
	initial_task_locations = [(x, y) for x in range(Env.shape[1]) for y in range(Env.shape[2]) if Env[1, x, y] == 1]
	initial_stop_locations = [(x, y) for x in range(Env.shape[1]) for y in range(Env.shape[2]) if Env[0, x, y] == 1]

	# 计算任务点之间的期望距离
	task_to_tasks_avg = {}
	for task_loc in initial_task_locations:
		dist_sum = sum(distance(task_loc, other_task) for other_task in initial_task_locations)
		task_to_tasks_avg[task_loc] = dist_sum / len(initial_task_locations) if initial_task_locations else 0

	# 计算停靠点之间的期望距离
	stop_to_stops_avg = {}
	for stop_loc in initial_stop_locations:
		dist_sum = sum(distance(stop_loc, other_stop) for other_stop in initial_stop_locations)
		stop_to_stops_avg[stop_loc] = dist_sum / len(initial_stop_locations) if initial_stop_locations else 0

	# 计算任务点到停靠点的期望距离
	task_to_stops_avg = {}
	for task_loc in initial_task_locations:
		dist_sum = sum(distance(task_loc, stop) for stop in initial_stop_locations)
		task_to_stops_avg[task_loc] = dist_sum / len(initial_stop_locations) if initial_stop_locations else 0

	# 计算停靠点到任务点的期望距离
	stop_to_tasks_avg = {}
	for stop_loc in initial_stop_locations:
		dist_sum = sum(distance(stop_loc, task) for task in initial_task_locations)
		stop_to_tasks_avg[stop_loc] = dist_sum / len(initial_task_locations) if initial_task_locations else 0

	# 创建一个位置类型字典，用于快速查询位置类型
	location_types = {}
	for loc in initial_task_locations:
		location_types[loc] = "task"
	for loc in initial_stop_locations:
		location_types[loc] = "stop"

	# 计算每个位置到任务点的期望距离
	avg_dist_to_tasks = {}
	all_locations = set(initial_task_locations) | set(initial_stop_locations)
	for loc in all_locations:
		dist_sum = sum(distance(loc, task) for task in initial_task_locations)
		avg_dist_to_tasks[loc] = dist_sum / len(initial_task_locations) if initial_task_locations else 0

	# 计算每个位置到停靠点的期望距离
	avg_dist_to_stops = {}
	for loc in all_locations:
		dist_sum = sum(distance(loc, stop) for stop in initial_stop_locations)
		avg_dist_to_stops[loc] = dist_sum / len(initial_stop_locations) if initial_stop_locations else 0
	# =====================距离期望值的预计算=====================

	Row, Lin = Env.shape[1], Env.shape[2]
	# 统计需要完成的任务数
	AllTask = sum(sum(Env[1, :, :]))
	total_data = float(np.sum(task_data))

	# 初始化通信车记忆管理器
	memory_manager = CommCarMemoryManager(Map_size, global_task_matrix)

	result_counts = Counter()  # 用来统计不同完成率出现的次数
	# 打开一个 CSV 文件，准备写入
	# 首先写表头
	with open('0810result.csv', 'w', newline='', encoding='utf-8') as f:
		writer = csv.writer(f)
		writer.writerow(['round', 'result', 'offload_rate', 'max_result', 'min_result', 'match_time'])

	for count in range(1):
		start_time = time.time()
		offloaded_sum = 0
		# 全局时间信息
		CurrTime = 1
		# 使用 np.copy() 创建副本
		Agents_copy = np.copy(Agents_list)
		Env_copy = np.copy(Env)
		system_task = []

		# 新增：初始化通信车记忆
		comm_cars_initial = [agent for agent in Agents_copy if agent[5] == 4]
		memory_manager.init_comm_memory(comm_cars_initial, Env_copy)

		while CurrTime * SingleStep < TimeLimit:
			Curr_Agents = []  # 本时刻所有激活智能体
			Curr_Com = []  # 本时刻可通信的通信汽车
			DataNO = []  # 索引映射
			SystemTime = CurrTime * SingleStep

			# 筛选激活智能体
			for agentIndex, agent in enumerate(Agents_copy):
				uptime, downtime = agent[1], agent[4]
				is_over_downtime = agent[9]

				# if uptime <= SystemTime <= downtime or (is_over_downtime == 1 and uptime <= SystemTime):
				if uptime <= SystemTime <= downtime:
					Curr_Agents.append(agent)
					DataNO.append(agentIndex)
					agent_type = agent[5]
					# 通信汽车只有在 full_memory (can_comm) 为1时才可通信
					if agent_type == 4 and agent[8] == 1.0:
						Curr_Com.append(agent)

			# 若无激活智能体，提前结束
			if not Curr_Agents:
				break

			# =================== 第一部分：通信车调度 ===================
			# 分离出通信车和其他智能体
			comm_cars = [agent for agent in Curr_Agents if agent[5] == 4]
			other_agents = [agent for agent in Curr_Agents if agent[5] != 4]

			comm_actions_dict = {}  # 使用字典存储通信车动作
			comm_move_steps_dict = {}  # 存储移动所需时间步数

			# 步骤1: 通信车根据当前位置更新记忆矩阵
			for car in comm_cars:
				memory_manager.update_comm_memory_from_reality(car, Env_copy, radius)

			# 步骤2: 通信车之间共享记忆矩阵
			memory_manager.share_comm_memory(comm_cars, radius)

			# 步骤3: 调度通信车

			# 先记录所有车的原始位置
			old_positions = {car[0]: (car[2], car[3]) for car in comm_cars}
			# 调度通信车
			comm_actions = schedule_comm_cars(comm_cars, memory_manager, radius, SingleStep)

			for i, car in enumerate(comm_cars):
				car_id = car[0]
				old_pos = old_positions[car_id]
				new_pos = comm_actions[i]
				comm_actions_dict[car_id] = new_pos

				# 立即更新通信车位置
				update_comm_car_positions(comm_cars, comm_actions, stop_positions)

			# 步骤4: 通信车移动到新位置后再次更新记忆矩阵
			for car in comm_cars:
				memory_manager.update_comm_memory_from_reality(car, Env_copy, radius)

			# 步骤5: 通信车之间再次共享记忆矩阵
			memory_manager.share_comm_memory(comm_cars, radius)

			# 步骤6: 更新所有智能体的可见任务矩阵
			memory_manager.update_agent_visible_tasks(Curr_Agents, comm_cars, radius)

			# =================== 第二部分：其他智能体调度 ===================
			# 获取各智能体在本时刻的决策行为
			actions, nash_count = get_behavior(Curr_Agents, Curr_Com, radius, Env_copy, task_data, SingleStep,
											   SystemTime, TimeLimit, Env, memory_manager, max_iter=100,
											   comm_actions_dict=comm_actions_dict)  # 传入字典

			print(f"------SystemTime:{SystemTime},在线智能体个数:{len(Curr_Agents)}------")
			print(f"actions:{actions}")
			# 更新环境与智能体状态
			Env_copy, Curr_Agents, DelatTime, finish_task, offload = update_environment(
				Env_copy, Curr_Agents, actions, SingleStep, task_data, SystemTime,
				memory_manager, Curr_Com, radius)  # 添加额外参数

			offloaded_sum += offload
			print(offloaded_sum)

			system_task.append(finish_task)
			# 回写 Agents_copy
			for i, agent in enumerate(Curr_Agents):
				idx = DataNO[i]
				Agents_copy[idx][2] = agent[2]  # 更新x坐标
				Agents_copy[idx][3] = agent[3]  # 更新y坐标

				# 更新通信能力
				if agent[5] == 4:
					Agents_copy[idx][8] = agent[8]

				if Agents_copy[idx][9] == 1:
					Agents_copy[idx][9] = 0
				# 下次可调度时刻 = 当前时刻 + 消耗时间
				Agents_copy[idx][1] = SystemTime + DelatTime[i]
				if Agents_copy[idx][1] > Agents_copy[idx][4] and Agents_copy[idx][9] == 0:
					Agents_copy[idx][9] = 1

				# 更新剩余能量字段（对 UAV 有意义，对通信车作为 can_comm 保持不变）
				if agent[5] == 3:
					Agents_copy[idx][7] = agent[7]

			# 步骤7: 任务执行后更新通信车记忆矩阵（检测通信范围内任务完成情况）
			for car in comm_cars:
				memory_manager.update_comm_memory_from_reality(car, Env_copy, radius)

			# 步骤8: 通信车之间再次共享记忆矩阵
			memory_manager.share_comm_memory(comm_cars, radius)

			# 更新全局时间信息
			CurrTime = CurrTime + 1

		####
		ComplateTask = sum(sum(Env_copy[1, :, :]))
		result = (AllTask - ComplateTask) / AllTask
		offload_rate = offloaded_sum / total_data
		offload_rate = round(offload_rate, 4)
		if result > max_result:
			max_result = result
		if result < min_result:
			min_result = result
		print("*************************")
		print(
			f"第{count}轮,卸载率:{offload_rate}")
		end_time = time.time()
		# 计算耗时
		elapsed_time = end_time - start_time
		# 将时间转换为分钟、秒和毫秒
		minutes = int(elapsed_time // 60)  # 计算分钟
		seconds = int(elapsed_time % 60)  # 计算秒
		milliseconds = int((elapsed_time * 1000) % 1000)  # 计算毫秒
		elapsed_str = f"{minutes}分{seconds}秒{milliseconds}毫秒"


		result_key = round(result, 5)
		result_counts[result_key] += 1
		# 每轮都以追加模式打开，写完马上关
		with open('0810result.csv', 'a', newline='', encoding='utf-8') as f:
			writer = csv.writer(f)
			writer.writerow(
				[count, f"{result:.5f}", f"{offload_rate:.5f}", f"{max_result:.5f}", f"{min_result:.5f}", elapsed_str])
