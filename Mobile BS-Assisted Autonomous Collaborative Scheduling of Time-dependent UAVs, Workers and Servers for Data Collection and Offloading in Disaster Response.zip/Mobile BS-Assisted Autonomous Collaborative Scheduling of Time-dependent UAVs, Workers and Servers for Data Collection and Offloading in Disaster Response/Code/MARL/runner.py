import copy
import torch
import qmix
import numpy as np
from scipy.io import loadmat
import time
from Tool import s_obs_avail_action
from Tool import Update_Agent_Loc
from readData import read_data

use_cuda = torch.cuda.is_available()
device = torch.device("cuda:0" if use_cuda else "cpu")
print("Using device:", device)

if use_cuda:
    # 获取指定设备的GPU名称
    gpu_name = torch.cuda.get_device_name(device)
    print(f"GPU Model: {gpu_name}")

# 灾后黄金救援72小时，24小时存活率：90%左右；48小时存活率：50%-60%；72小时存活率：20%-30%
if __name__ == '__main__':
    # 全局时间标识--用于全局时间参考标准，表示TimeLimit个时间步长，size：1
    TimeLimit = 240
    SingleStep = 5
    ConnectRange = 8

    # DataTrain = loadmat('E:/pythonProject/P_QMIX_Space_Task--New - 副本/Data/滴滴订单数据--全1.mat',  mat_dtype=True)
    # DataTest = loadmat('E:/pythonProject/P_QMIX_Space_Task--New - 副本/Data/滴滴订单数据--全1.mat',mat_dtype=True)

    # 修改：接收 read_data 返回的 total_task_power
    uav_list, worker_list, car_list, com_list, Agents_list, Env, Task_Time, charge_positions, total_task_power = read_data(
        row=30, col=30)

    # 环境信息包含两种信息：续航点位置点标识，任务点位置标识，size：2*Row*Lin
    Env_Train = np.copy(Env)

    # 智能体数据：id序号、起始时刻、【起始位置Lin、起始位置Row】、终止时刻、智能体类型、移动速度、起始时刻续航、满电续航
    Order_Finall_Train = np.copy(Agents_list)
    # 提取第7列（索引为6），即速度数据
    speed_Train = Order_Finall_Train[:, 6]

    # 完成每个任务所需的代价消耗/
    # Task_Time = np.copy(DataTrain['Task_Time'])

    # 环境信息包含两种信息：续航点位置点标识，任务点位置标识，size：2*Row*Lin
    Env_Test = np.copy(Env)
    # 智能体数据：日期、起始时刻、【起始位置Lin、起始位置Row】、终止时刻、智能体类型、移动速度、起始时刻续航、满电续航
    Order_Finall_Test = np.copy(Agents_list)
    # 提取第7列（索引为6），即速度数据
    speed_Test = Order_Finall_Test[:, 6]

    # 完成每个任务所需的代价消耗
    # Task_Time = np.copy(DataTrain['Task_Time'])

    # 获取续航最短无人机满电状态
    min_value_Train = 1000000
    for agentIndex in range(Order_Finall_Train.shape[0]):
        if Order_Finall_Train[agentIndex, 5] == 3 and Order_Finall_Train[agentIndex, 8] < min_value_Train:
            min_value_Train = Order_Finall_Train[agentIndex, 8]

    # 获取续航最短无人机满电状态
    min_value_Test = 1000000
    for agentIndex in range(Order_Finall_Test.shape[0]):
        if Order_Finall_Test[agentIndex, 5] == 3 and Order_Finall_Test[agentIndex, 8] < min_value_Test:
            min_value_Test = Order_Finall_Test[agentIndex, 8]

    # 确定智能体数量上限
    WorkerNum = 0
    CarNum = 0
    UAVNum = 0
    ComNum = 0  # 通信无人机数量

    for Time_i in range(1, int(TimeLimit / SingleStep + 1)):
        WorkerNumTemp = 0
        CarNumTemp = 0
        UAVNumTemp = 0
        ComNumTemp = 0
        for agentIndex in range(Order_Finall_Train.shape[0]):
            ## 当前的时间在上下线时间之间 ，寻找符合此刻在线的 worker，car ,uav，然后num++
            if Order_Finall_Train[agentIndex, 5] == 1 and Order_Finall_Train[
                agentIndex, 1] <= Time_i * SingleStep < Order_Finall_Train[agentIndex, 4]:
                WorkerNumTemp = WorkerNumTemp + 1
            if Order_Finall_Train[agentIndex, 5] == 2 and Order_Finall_Train[
                agentIndex, 1] <= Time_i * SingleStep < Order_Finall_Train[agentIndex, 4]:
                CarNumTemp = CarNumTemp + 1
            if Order_Finall_Train[agentIndex, 5] == 3 and Order_Finall_Train[
                agentIndex, 1] <= Time_i * SingleStep < Order_Finall_Train[agentIndex, 4]:
                UAVNumTemp = UAVNumTemp + 1
            # 新增通信无人机
            if Order_Finall_Train[agentIndex, 5] == 4 and Order_Finall_Train[
                agentIndex, 1] <= Time_i * SingleStep < Order_Finall_Train[agentIndex, 4]:
                ComNumTemp = ComNumTemp + 1

        if WorkerNumTemp > WorkerNum:
            WorkerNum = np.copy(WorkerNumTemp)
        if CarNumTemp > CarNum:
            CarNum = np.copy(CarNumTemp)
        if UAVNumTemp > UAVNum:
            UAVNum = np.copy(UAVNumTemp)
        if ComNumTemp > ComNum:  # 增加通信无人机
            ComNum = np.copy(ComNumTemp)

    # 获取智能体数量
    Agent_Num = int(WorkerNum + CarNum + UAVNum + ComNum)
    # 获取感知区域大小
    Row = Env_Train.shape[1]
    Lin = Env_Train.shape[2]

    memory_tasks = np.zeros((len(Agents_list), Env.shape[1], Env.shape[2]))
    # 填充 memory_tasks
    for i in range(len(Agents_list)):
        memory_tasks[i, :, :] = Env[1, :, :]  # 假设你想要每个代理的任务都是相同的
    Env_start = np.copy(Env)

    # 对象化多智能体强化学习算法
    qmix_algo = qmix.QMix(0.0001, 0.99, 1, 0.02, 5000, 64, 128, Agent_Num, Row, Lin)
    # # 模型存放路径
    # filename_CNN = './model/CNN'
    # filename_agent = './model/agent'
    # filename_qmixer = './model/qmixer'
    # # 导入模型
    # qmix_algo.load_model(filename_CNN, filename_agent, filename_qmixer)

    name = "../Result/z_output" + ".txt"
    with open(name, 'w', encoding='utf-8') as file:
        # 写入字符串
        file.write('Hello, World!\n')
        file.write('This is ' + name + '\n\n')
    # 训练数据迭代次数
    TrainNum = 50000
    for episode in range(TrainNum):
        print("episode is ", episode)

        if episode % 100 == 0:  # 每100个episode保存一次
            qmix_algo.save_model(
                './model/CNN.pth',
                './model/agent.pth',
                './model/qmixer.pth'
            )
            print(f"[INFO] Episode {episode}: model saved.")

        # 差一个训练数据赋值
        Temp_Train = np.copy(Order_Finall_Train)

        # 全局时间信息
        CurrTime = 1
        # 取出训练数据
        Env_Train_ = np.copy(Env_Train)  # 2*Row*Lin    s = np.zeros((5,Row,Lin))
        Agent_Sign_ = np.zeros((Agent_Num))  # AgentNum
        Agent_Loc_ = np.zeros((Agent_Num, Row, Lin))  # AgentNum*Row*Lin
        Energy_ = np.zeros((Agent_Num))  # AgentNum
        PowerConsum_ = np.zeros((Agent_Num))  # AgentNum
        Energy_FULL = np.zeros((Agent_Num))
        DataNO = np.zeros((Agent_Num))  # 记录当前智能体在测试集中是哪条数据
        memory_tasks_copy = np.copy(memory_tasks)

        # 新增：初始化训练过程中的总充电量
        total_recharged_energy_train = 0.0

        #  分别为工人、车辆、无人机的计数器，用于分配智能体。
        CurrIndex_W = 0
        CurrIndex_C = 0
        CurrIndex_U = 0
        CurrIndex_Com = 0
        Curr_Agents = []  # 本时刻所有激活智能体
        Curr_Com = []  # 本时刻可通信的通信汽车
        #  agentIndex在全部的智能体列表的序号
        for agentIndex in range(Temp_Train.shape[0]):
            # 找到日期为DayNum[CurrDate]的智能体
            if CurrTime * SingleStep >= Temp_Train[agentIndex, 1] and CurrTime * SingleStep < Temp_Train[agentIndex, 4]:
                Curr_Agents.append(Temp_Train[agentIndex])
                if Temp_Train[agentIndex, 5] == 1:
                    Agent_Sign_[CurrIndex_W] = Temp_Train[agentIndex, 5]  # 智能体类型
                    Agent_Loc_[CurrIndex_W, int(Temp_Train[agentIndex, 2]), int(Temp_Train[agentIndex, 3])] = 1  # 坐标位置
                    PowerConsum_[CurrIndex_W] = Temp_Train[agentIndex, 6]  # 每公里耗电？速度啦
                    DataNO[CurrIndex_W] = agentIndex  # 记录当前数据是哪一条，以用于还原数据
                    CurrIndex_W = CurrIndex_W + 1
                if Temp_Train[agentIndex, 5] == 2:
                    Agent_Sign_[WorkerNum + CurrIndex_C] = Temp_Train[agentIndex, 5]
                    # Bug fix: a few lines had "- 1" for coordinates, removed for consistency
                    Agent_Loc_[WorkerNum + CurrIndex_C, int(Temp_Train[agentIndex, 2]), int(
                        Temp_Train[agentIndex, 3])] = 1
                    PowerConsum_[WorkerNum + CurrIndex_C] = Temp_Train[agentIndex, 6]
                    Energy_FULL[WorkerNum + CurrIndex_C] = Temp_Train[agentIndex, 8]  # 满电
                    DataNO[WorkerNum + CurrIndex_C] = agentIndex  # 记录当前数据是哪一条，以用于还原数据
                    CurrIndex_C = CurrIndex_C + 1
                if Temp_Train[agentIndex, 5] == 3:
                    Agent_Sign_[WorkerNum + CarNum + CurrIndex_U] = Temp_Train[agentIndex, 5]
                    Agent_Loc_[WorkerNum + CarNum + CurrIndex_U, int(Temp_Train[agentIndex, 2]), int(
                        Temp_Train[agentIndex, 3])] = 1
                    Energy_[WorkerNum + CarNum + CurrIndex_U] = Temp_Train[agentIndex, 7]  # 当前电量
                    PowerConsum_[WorkerNum + CarNum + CurrIndex_U] = Temp_Train[agentIndex, 6]
                    Energy_FULL[WorkerNum + CarNum + CurrIndex_U] = Temp_Train[agentIndex, 8]  # 满电电量
                    DataNO[WorkerNum + CarNum + CurrIndex_U] = agentIndex  # 记录当前数据是哪一条，以用于还原数据
                    CurrIndex_U = CurrIndex_U + 1
                if Temp_Train[agentIndex, 5] == 4:
                    Curr_Com.append(Temp_Train[agentIndex])
                    Agent_Sign_[WorkerNum + CarNum + UAVNum + CurrIndex_Com] = Temp_Train[agentIndex, 5]  # 类型
                    Agent_Loc_[WorkerNum + CarNum + UAVNum + CurrIndex_Com, int(Temp_Train[agentIndex, 2]), int(
                        Temp_Train[agentIndex, 3])] = 1  # 地点
                    PowerConsum_[WorkerNum + CarNum + UAVNum + CurrIndex_Com] = Temp_Train[agentIndex, 6]  # 每公里耗电？
                    DataNO[WorkerNum + CarNum + UAVNum + CurrIndex_Com] = agentIndex  # 记录当前数据是哪一条，以用于还原数据
                    CurrIndex_Com = CurrIndex_Com + 1

        # # 记录智能体当前是否刊用
        # Agent_avail_Train = [
        #     [i, True, 0, Row + 1, Lin + 1, Row + 1, Lin + 1]  # 每个智能体的初始状态：编号、是否可用、下一次可用时间，上次选的下次位置,现在的位置
        #     for i in range(len(Order_Finall_Train))
        # ]

        # 将环境信息转换成当前全局状态和局部观察以及可执行行为
        s, obs, avail_action, all_connet = s_obs_avail_action(Env_Train_, Agent_Sign_, Agent_Loc_, Energy_,
                                                              min_value_Train,
                                                              Task_Time, ConnectRange, Curr_Agents, Curr_Com,
                                                              memory_tasks_copy, Env_start, DataNO, Temp_Train,
                                                              CurrTime * SingleStep, TimeLimit)

        # print(f"s:\n{s}")
        # print(f"obs:\n{obs}")
        # print(f"avail_action: \n{avail_action}")

        # print(CurrIndex_W)
        # print(CurrIndex_C)
        # print(CurrIndex_U)

        # 设置是否到达终止目标的标识
        t = 0
        while CurrTime * SingleStep < TimeLimit:
            torch.cuda.empty_cache()
            # 更新全局时间信息
            CurrTime = CurrTime + 1

            # 得到action，行为可变的，在不同状态下，行为的选择范围不一样
            action, is_end = qmix_algo.choose_action(obs, avail_action)
            if is_end == 1:
                break

            actions_curr = {}
            for Agent_Index in range(Agent_Num):
                if Agent_Sign_[Agent_Index] > 0:
                    agent = Temp_Train[int(DataNO[Agent_Index])]
                    idx = int(round(action[Agent_Index]))  # 确保整数
                    x, y = divmod(idx, Lin)
                    actions_curr[int(agent[0])] = (x, y)

            # 更新环境任务信息、智能体位置信息、无人机剩余电量，以及计算奖励
            # 修改：传入并接收 total_recharged_energy_train
            Env_Train_, Agent_Loc_, Energy_, r, DelatTime, total_recharged_energy_train = Update_Agent_Loc(Env_Train_,
                                                                                                           Agent_Sign_,
                                                                                                           Energy_,
                                                                                                           PowerConsum_,
                                                                                                           action,
                                                                                                           Agent_Loc_,
                                                                                                           Energy_FULL,
                                                                                                           Task_Time,
                                                                                                           memory_tasks_copy,
                                                                                                           all_connet,
                                                                                                           DataNO,
                                                                                                           Temp_Train,
                                                                                                           total_recharged_energy_train)
            for Agent_Index in range(Agent_Num):
                # 找到当前存在的智能体  =0 说明没有
                if Agent_Sign_[Agent_Index] > 0:
                    # 执行行为后，改变智能体位置
                    Temp_Train[int(DataNO[Agent_Index]), 1] = (CurrTime - 1) * SingleStep + DelatTime[Agent_Index]
                    Temp_Train[int(DataNO[Agent_Index]), 2] = int(action[Agent_Index] / (Lin))
                    Temp_Train[int(DataNO[Agent_Index]), 3] = int(action[Agent_Index] % (Lin))
                    Temp_Train[int(DataNO[Agent_Index]), 7] = Energy_[Agent_Index]

            ##执行行为后的环境和智能体信息更新完成##
            Agent_Sign_ = np.zeros((Agent_Num))  # AgentNum
            Agent_Loc_ = np.zeros((Agent_Num, Row, Lin))  # AgentNum*Row*Lin
            Energy_ = np.zeros((Agent_Num))  # AgentNum
            PowerConsum_ = np.zeros((Agent_Num))  # AgentNum
            Energy_FULL = np.zeros((Agent_Num))
            DataNO = np.zeros((Agent_Num))  # 记录当前智能体在测试集中是哪条数据
            CurrIndex_W = 0
            CurrIndex_C = 0
            CurrIndex_U = 0
            CurrIndex_Com = 0
            Curr_Agents = []  # 本时刻所有激活智能体
            Curr_Com = []  # 本时刻可通信的通信汽车
            for agentIndex in range(Temp_Train.shape[0]):
                if CurrTime * SingleStep >= Temp_Train[agentIndex, 1] and CurrTime * SingleStep < Temp_Train[
                    agentIndex, 4]:
                    Curr_Agents.append(Temp_Train[agentIndex])
                    if Temp_Train[agentIndex, 5] == 1:
                        Agent_Sign_[CurrIndex_W] = Temp_Train[agentIndex, 5]  # 智能体类型
                        Agent_Loc_[
                            CurrIndex_W, int(Temp_Train[agentIndex, 2]), int(Temp_Train[agentIndex, 3])] = 1  # 坐标位置
                        PowerConsum_[CurrIndex_W] = Temp_Train[agentIndex, 6]  # 每公里耗电？
                        DataNO[CurrIndex_W] = agentIndex  # 记录当前数据是哪一条，以用于还原数据
                        CurrIndex_W = CurrIndex_W + 1
                    if Temp_Train[agentIndex, 5] == 2:
                        Agent_Sign_[WorkerNum + CurrIndex_C] = Temp_Train[agentIndex, 5]
                        Agent_Loc_[
                            WorkerNum + CurrIndex_C, int(Temp_Train[agentIndex, 2]), int(Temp_Train[agentIndex, 3])] = 1
                        PowerConsum_[WorkerNum + CurrIndex_C] = Temp_Train[agentIndex, 6]
                        Energy_FULL[WorkerNum + CurrIndex_C] = Temp_Train[agentIndex, 8]  # 满电
                        DataNO[WorkerNum + CurrIndex_C] = agentIndex  # 记录当前数据是哪一条，以用于还原数据
                        CurrIndex_C = CurrIndex_C + 1
                    if Temp_Train[agentIndex, 5] == 3:
                        Agent_Sign_[WorkerNum + CarNum + CurrIndex_U] = Temp_Train[agentIndex, 5]
                        Agent_Loc_[WorkerNum + CarNum + CurrIndex_U, int(Temp_Train[agentIndex, 2]), int(
                            Temp_Train[agentIndex, 3])] = 1
                        Energy_[WorkerNum + CarNum + CurrIndex_U] = Temp_Train[agentIndex, 7]  # 当前电量
                        PowerConsum_[WorkerNum + CarNum + CurrIndex_U] = Temp_Train[agentIndex, 6]
                        Energy_FULL[WorkerNum + CarNum + CurrIndex_U] = Temp_Train[agentIndex, 8]  # 满电电量
                        DataNO[WorkerNum + CarNum + CurrIndex_U] = agentIndex  # 记录当前数据是哪一条，以用于还原数据
                        CurrIndex_U = CurrIndex_U + 1
                    if Temp_Train[agentIndex, 5] == 4:
                        Curr_Com.append(Temp_Train[agentIndex])
                        Agent_Sign_[WorkerNum + CarNum + UAVNum + CurrIndex_Com] = Temp_Train[agentIndex, 5]
                        Agent_Loc_[WorkerNum + CarNum + UAVNum + CurrIndex_Com, int(Temp_Train[agentIndex, 2]), int(
                            Temp_Train[agentIndex, 3])] = 1
                        PowerConsum_[WorkerNum + CarNum + UAVNum + CurrIndex_Com] = Temp_Train[agentIndex, 6]  # 每公里耗电？
                        DataNO[WorkerNum + CarNum + UAVNum + CurrIndex_Com] = agentIndex  # 记录当前数据是哪一条，以用于还原数据
                        CurrIndex_Com = CurrIndex_Com + 1

            # 更新下一全局状态和局部观察信息以及可执行行为
            s_next, obs_next, avail_action_next, all_connet_next = s_obs_avail_action(Env_Train_, Agent_Sign_,
                                                                                      Agent_Loc_, Energy_,
                                                                                      min_value_Train, Task_Time,
                                                                                      ConnectRange, Curr_Agents,
                                                                                      Curr_Com,
                                                                                      memory_tasks_copy, Env_start,
                                                                                      DataNO, Temp_Train,
                                                                                      CurrTime * SingleStep, TimeLimit)

            # 判断是否达到终止目标
            if CurrTime * SingleStep >= TimeLimit:
                t = 1

            # 存入经验池
            qmix_algo.store_transition(s, s_next, obs, obs_next, avail_action, avail_action_next, action, r, t)

            # 经验池中的数据量达到要求就要开始训练网络模型了
            if qmix_algo.memory_counter > qmix_algo.memory_size:
                try:
                    qmix_algo.learn()
                except torch.cuda.OutOfMemoryError:
                    # 捕获到了显存不足的错误
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                    print("错误: GPU 显存不足 (CUDA out of memory)！")
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")

                    # 打印一些有用的调试信息
                    print(f"当前批次大小 (batch_size): {qmix_algo.batch_size}")
                    print(f"当前经验池大小 (memory_size): {qmix_algo.memory_size}")

                    # 清理一下显存，虽然此时可能已经晚了，但这是个好习惯
                    torch.cuda.empty_cache()

                    raise
                torch.cuda.empty_cache()

            # 更新全局观察
            s = np.copy(s_next)
            # 更新局部观察
            obs = np.copy(obs_next)
            # 更新可执行行为
            avail_action = np.copy(avail_action_next)
            all_connet = copy.deepcopy(all_connet_next)

        if episode % 5 == 0:
            before_time = time.time()
            print('##############################################')
            print(f"轮次:{episode}")

            # 新增：初始化测试过程的总充电量
            total_recharged_energy_test = 0.0
            # 统计需要完成的任数务
            AllTask = 0
            RemainTask = 0
            Temp_Test = np.copy(Order_Finall_Test)
            AllTask = AllTask + sum(sum(Env_Test[1, :, :]))
            Agent_Num_Test = 0

            Temp_Test = np.copy(Order_Finall_Test)
            Agent_Num_Test = 0
            # 全局时间信息
            CurrTime = 1
            for agentIndex in range(Temp_Test.shape[0]):
                if CurrTime * SingleStep >= Temp_Test[agentIndex, 1] and CurrTime * SingleStep < Temp_Test[
                    agentIndex, 4]:
                    Agent_Num_Test = Agent_Num_Test + 1
            # 取出测试数据
            Env_Test_ = np.copy(Env_Test)  # 2*Row*Lin
            Agent_Sign_ = np.zeros((Agent_Num_Test))  # AgentNum
            Agent_Loc_ = np.zeros((Agent_Num_Test, Row, Lin))  # AgentNum*Row*Lin
            Energy_ = np.zeros((Agent_Num_Test))  # AgentNum
            PowerConsum_ = np.zeros((Agent_Num_Test))  # AgentNum
            Energy_FULL = np.zeros((Agent_Num_Test))
            DataNO = np.zeros((Agent_Num_Test))  # 记录当前智能体在测试集中是哪条数据
            memory_tasks_copy = np.copy(memory_tasks)

            Curr_Agents = []  # 本时刻所有激活智能体
            Curr_Com = []  # 本时刻可通信的通信汽车
            CurrIndex = 0
            for agentIndex in range(Temp_Test.shape[0]):
                if CurrTime * SingleStep >= Temp_Test[agentIndex, 1] and CurrTime * SingleStep < Temp_Test[
                    agentIndex, 4]:
                    Curr_Agents.append(Temp_Test[agentIndex])  # Bug fix: Should use Temp_Test

                    Agent_Sign_[CurrIndex] = Temp_Test[agentIndex, 5]
                    # Bug fix: a few lines had "- 1" for coordinates, removed for consistency
                    Agent_Loc_[CurrIndex, int(Temp_Test[agentIndex, 2]), int(Temp_Test[agentIndex, 3])] = 1
                    Energy_[CurrIndex] = Temp_Test[agentIndex, 7]
                    PowerConsum_[CurrIndex] = Temp_Test[agentIndex, 6]
                    Energy_FULL[CurrIndex] = Temp_Test[agentIndex, 8]
                    DataNO[CurrIndex] = agentIndex
                    CurrIndex = CurrIndex + 1

                    if Temp_Test[agentIndex, 5] == 4:  # Bug fix: Should use Temp_Test
                        Curr_Com.append(Temp_Test[agentIndex])  # Bug fix: Should use Temp_Test

            # 将环境信息转换成当前全局状态和局部观察以及可执行行为
            s, obs, avail_action, all_connet = s_obs_avail_action(Env_Test_, Agent_Sign_, Agent_Loc_, Energy_,
                                                                  min_value_Test,
                                                                  Task_Time, ConnectRange, Curr_Agents, Curr_Com,
                                                                  memory_tasks_copy, Env_start, DataNO, Temp_Test,
                                                                  CurrTime * SingleStep, TimeLimit)

            while CurrTime * SingleStep < TimeLimit:
                # 更新全局时间信息
                CurrTime = CurrTime + 1
                # 得到action，行为可变的，在不同状态下，行为的选择范围不一样
                action = qmix_algo.max_action(obs, avail_action, Agent_Num_Test)
                # print(action)
                # print(action.shape)
                # 更新环境任务信息、智能体位置信息、无人机剩余电量，以及计算奖励

                # 修改：传入并接收 total_recharged_energy_test
                Env_Test_, Agent_Loc_, Energy_, r, DelatTime, total_recharged_energy_test = Update_Agent_Loc(Env_Test_,
                                                                                                             Agent_Sign_,
                                                                                                             Energy_,
                                                                                                             PowerConsum_,
                                                                                                             action,
                                                                                                             Agent_Loc_,
                                                                                                             Energy_FULL,
                                                                                                             Task_Time,
                                                                                                             memory_tasks_copy,
                                                                                                             all_connet,
                                                                                                             DataNO,
                                                                                                             Temp_Test,
                                                                                                             total_recharged_energy_test)
                for Agent_Index in range(Agent_Num_Test):
                    # 执行行为后，改变智能体位置
                    Temp_Test[int(DataNO[Agent_Index]), 1] = (CurrTime - 1) * SingleStep + DelatTime[Agent_Index]
                    Temp_Test[int(DataNO[Agent_Index]), 2] = int(action[Agent_Index] / (Lin))
                    Temp_Test[int(DataNO[Agent_Index]), 3] = int(action[Agent_Index] % (Lin))
                    Temp_Test[int(DataNO[Agent_Index]), 7] = Energy_[Agent_Index]
                ##执行行为后的环境和智能体信息更新完成##

                Agent_Num_Test = 0
                for agentIndex in range(Temp_Test.shape[0]):
                    if CurrTime * SingleStep >= Temp_Test[agentIndex, 1] and CurrTime * SingleStep < Temp_Test[
                        agentIndex, 4]:
                        Agent_Num_Test = Agent_Num_Test + 1
                # 取出测试数据
                Agent_Sign_ = np.zeros((Agent_Num_Test))  # AgentNum
                Agent_Loc_ = np.zeros((Agent_Num_Test, Row, Lin))  # AgentNum*Row*Lin
                Energy_ = np.zeros((Agent_Num_Test))  # AgentNum
                PowerConsum_ = np.zeros((Agent_Num_Test))  # AgentNum
                Energy_FULL = np.zeros((Agent_Num_Test))
                DataNO = np.zeros((Agent_Num_Test))  # 记录当前智能体在测试集中是哪条数据

                Curr_Agents = []  # 本时刻所有激活智能体
                Curr_Com = []  # 本时刻可通信的通信汽车

                CurrIndex = 0
                for agentIndex in range(Temp_Test.shape[0]):
                    if CurrTime * SingleStep >= Temp_Test[agentIndex, 1] and CurrTime * SingleStep < Temp_Test[
                        agentIndex, 4]:
                        Curr_Agents.append(Temp_Test[agentIndex])  # Bug fix: Should use Temp_Test

                        Agent_Sign_[CurrIndex] = Temp_Test[agentIndex, 5]
                        Agent_Loc_[CurrIndex, int(Temp_Test[agentIndex, 2]), int(Temp_Test[agentIndex, 3])] = 1
                        Energy_[CurrIndex] = Temp_Test[agentIndex, 7]
                        PowerConsum_[CurrIndex] = Temp_Test[agentIndex, 6]
                        Energy_FULL[CurrIndex] = Temp_Test[agentIndex, 8]
                        DataNO[CurrIndex] = agentIndex
                        CurrIndex = CurrIndex + 1

                        if Temp_Test[agentIndex, 5] == 4:  # Bug fix: Should use Temp_Test
                            Curr_Com.append(Temp_Test[agentIndex])  # Bug fix: Should use Temp_Test

                # print(Energy_)
                # 更新下一全局状态和局部观察信息以及可执行行为

                s_next, obs_next, avail_action_next, all_connet_next = s_obs_avail_action(Env_Test_, Agent_Sign_,
                                                                                          Agent_Loc_, Energy_,
                                                                                          min_value_Test, Task_Time,
                                                                                          ConnectRange, Curr_Agents,
                                                                                          Curr_Com,
                                                                                          memory_tasks_copy, Env_start,
                                                                                          DataNO, Temp_Test,
                                                                                          CurrTime * SingleStep,
                                                                                          TimeLimit)
                # 判断是否达到终止目标
                if CurrTime * SingleStep >= TimeLimit:
                    RemainTask = RemainTask + sum(sum(Env_Test_[1, :, :]))

                # 更新全局观察
                s = np.copy(s_next)
                # 更新局部观察
                obs = np.copy(obs_next)
                # 更新可执行行为
                avail_action = np.copy(avail_action_next)

                all_connet = copy.deepcopy(all_connet_next)

            # qmix_algo.save_model(filename_CNN, filename_agent, filename_qmixer)

            # 修改：计算并输出电量利用率
            if total_task_power > 0:
                power_utilization_rate = total_recharged_energy_test / total_task_power
            else:
                power_utilization_rate = 0.0  # 避免除以零

            print(f"AllTask:{AllTask}")
            print(f"RemainTask:{RemainTask}")
            print("任务完成率:", (AllTask - RemainTask) / AllTask)
            print(f"总任务数据量: {total_task_power}")
            print(f"数据卸载量: {total_recharged_energy_test}")
            print(f"卸载率: {power_utilization_rate}")

            after_time = time.time()
            # 计算耗时
            elapsed_time = after_time - before_time
            # 将时间转换为分钟、秒和毫秒
            minutes = int(elapsed_time // 60)  # 计算分钟
            seconds = int(elapsed_time % 60)  # 计算秒
            milliseconds = int((elapsed_time * 1000) % 1000)  # 计算毫秒
            elapsed_str = f"{minutes}分{seconds}秒{milliseconds}毫秒"

            print(f"耗时:{elapsed_str}")

            # 修改：将新的指标写入文件
            with open(name, 'a', encoding='utf-8') as file:
                file.write('##############################################\n')
                file.write(f"轮次:{episode}\n")
                file.write(f"AllTask:{AllTask}\n")
                file.write(f"RemainTask:{RemainTask}")
                file.write("任务完成率: " + str((AllTask - RemainTask) / AllTask) +"\n")
                file.write(f"总任务数据量: {total_task_power}\n")
                file.write(f"数据卸载量: {total_recharged_energy_test}\n")
                file.write(f"卸载率: {power_utilization_rate}\n")
                file.write(f"耗时:{elapsed_str}\n\n")