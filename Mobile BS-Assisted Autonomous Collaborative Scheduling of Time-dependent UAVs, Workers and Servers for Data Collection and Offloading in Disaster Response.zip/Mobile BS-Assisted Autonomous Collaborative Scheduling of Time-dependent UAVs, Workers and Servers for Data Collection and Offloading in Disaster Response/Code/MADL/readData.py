"""
readData.py

模块功能：读取由 Data_maker.py 生成的 CSV 文件，构建环境和智能体列表，便于后续调度算法调用。

函数:
  - read_data(row, col, file_prefix='')
      返回: Env (2, row, col)、Task_Time (row, col)、Curr_Agents (list)
"""
import csv
import numpy as np
import os


def _read_csv_dicts(filename):
    """以字典列表方式读取 CSV 文件"""
    with open(filename, mode='r', newline='') as f:
        reader = csv.DictReader(f)
        return list(reader)


def read_data(row, col, file_prefix=''):
    """
    读取所有场景数据文件，构造环境与智能体列表。

    参数:
      row, col: 可选, 地图边长.
      file_prefix: 可选, CSV 文件的路径前缀.

    返回:
      Env: ndarray, shape (2,row, col), 0=续航/停靠点, 1=任务点
      Task_Time: ndarray, shape (row, col), 任务耗时矩阵, 0=无任务
      Curr_Agents: list of [date, uptime, x, y, downtime, type, speed, energy, full_energy]
    """
    # 文件路径
    uav_file = os.path.join(file_prefix, '../Data/uavMap.csv')
    worker_file = os.path.join(file_prefix, '../Data/workerMap.csv')
    car_file = os.path.join(file_prefix, '../Data/serverMap.csv')
    comm_file = os.path.join(file_prefix, '../Data/commMap.csv')
    task_file = os.path.join(file_prefix, '../Data/taskMap.csv')
    charge_file = os.path.join(file_prefix, '../Data/stopMap.csv')

    # 读取 CSV
    uav_list = _read_csv_dicts(uav_file)
    worker_list = _read_csv_dicts(worker_file)
    car_list = _read_csv_dicts(car_file)
    comm_list = _read_csv_dicts(comm_file)
    task_list = _read_csv_dicts(task_file)
    charge_list = _read_csv_dicts(charge_file)



    # 初始化环境
    Env = np.zeros((2, row, col), dtype=int)
    Task_Time = np.zeros((row, col), dtype=int)

    # 新增：初始化总任务耗电量
    total_task_power = 0

    # 填充任务点
    for row_data in task_list:  # 变量名修改以避免与参数 row 冲突
        x, y = int(row_data['x']), int(row_data['y'])
        task_power = int(row_data['T_datasize'])
        Env[1, x, y] = 1
        Task_Time[x, y] = task_power
        total_task_power += task_power  # 累加任务耗电

    # 填充续航/停靠点
    for row_data in charge_list:  # 变量名修改
        x, y = int(row_data['x']), int(row_data['y'])
        Env[0, x, y] = 1

    # 构造统一的智能体列表
    # 先收集停靠点位置，判断通信汽车初始是否能提供通信
    charge_positions = {(int(r['x']), int(r['y'])) for r in charge_list}

    Agents_list = []  # [ uptime, downtime, x, y, type, speed, energy, full_energy]
    id = 0
    is_over_downtime = 0.0
    # 工人 (type=1)，无能量字段
    for row_data in worker_list:  # 变量名修改
        Agents_list.append([
            int(id),
            int(row_data['W_uptime']),
            int(row_data['x']),
            int(row_data['y']),
            int(row_data['W_downtime']),
            1,
            float(row_data['workerRge']),
            0.0,
            0.0,
            is_over_downtime
        ])
        id += 1
    # 充电汽车 (type=2)，energy字段不使用，full_energy存充电功率
    for row_data in car_list:  # 变量名修改
        Agents_list.append([
            int(id),
            int(row_data['S_uptime']),
            int(row_data['x']),
            int(row_data['y']),
            int(row_data['S_downtime']),
            2,
            float(row_data['serverRge']),
            0.0,
            float(row_data['S_throughput']),
            is_over_downtime
        ])
        id += 1
    # 感知无人机 (type=3)
    for row_data in uav_list:
        Agents_list.append([
            int(id),
            int(row_data['U_uptime']),
            int(row_data['x']),
            int(row_data['y']),
            int(row_data['U_downtime']),
            3,
            float(row_data['uavRge']),
            float(row_data['uMemory']),
            float(row_data['Fullmemory']),
            is_over_downtime
        ])
        id += 1
    # 通信汽车 (type=4)，无能量字段
    for row_data in comm_list:  # 变量名修改
        x, y = int(row_data['x']), int(row_data['y'])
        can_comm = 1 if (x, y) in charge_positions else 0
        Agents_list.append([
            int(id),
            int(row_data['Com_uptime']),
            int(row_data['x']),
            int(row_data['y']),
            int(row_data['Com_downtime']),
            4,
            float(row_data['commRge']),
            0.0,
            can_comm,
            is_over_downtime
        ])
        id += 1

    return uav_list, worker_list, car_list, comm_list, Agents_list, Env, Task_Time, charge_positions, total_task_power



# 调试示例
if __name__ == '__main__':
    row =30
    col = 30
    LIMIT_TIME = 180
    uav_list, worker_list, car_list, comm_list, Agents_list, Env, Task_Time, charge_positions, total_task_power = read_data(row, col)

    print('UAV:', len(uav_list), 'Workers:', len(worker_list), 'Chargers:', len(car_list), 'ComCars:', len(comm_list))
    print('Env shape:', Env.shape, 'Tasks:', np.count_nonzero(Task_Time), 'Charges:', np.count_nonzero(Env[0, :, :]))
    print('Total Task Power Cost:', total_task_power)  # 打印总耗电
    print('worker:', worker_list[0])
    print('Car', car_list[0])
    print('UAV', uav_list[0])
    print('com', comm_list[0])
    for agent in Agents_list:
        print('agent:\n', agent)
