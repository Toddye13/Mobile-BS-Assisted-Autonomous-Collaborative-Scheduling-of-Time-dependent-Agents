import copy

import numpy as np
import math
import random

from networkx.algorithms.distance_measures import radius

np.set_printoptions(threshold=np.inf)  # threshold 指定超过多少使用省略号，np.inf代表无限大


def distance(agent1, agent2):
    """计算两个智能体之间的欧几里得距离"""
    return np.linalg.norm(np.array(agent1) - np.array(agent2))
    # return np.linalg.norm(agent1 - agent2)


# Env是真实的
def s_obs_avail_action(Env, Agent_Sign, Agent_Loc, Energy, min_value, Task_Time, ConnectRange, Curr_Agents, Curr_Com,
                       memory_tasks, Env_start, DataNO, Temp_Train, SysTime, TimeLimit):
    # 获取空间纵横宽度
    Row = Env.shape[1]
    Lin = Env.shape[2]
    # 获取智能体数量
    Agent_Num = Agent_Sign.shape[0]
    # 构建全局矩阵s：障碍物、任务点、用户位置、补给车位置、无人机位置、-->无人机电量、无人机耗电
    # s = np.zeros((6,Row,Lin))
    s = np.zeros((7, Row, Lin))  # 我们新增一下通信无人机的
    s[0:2, :, :] = Env
    com_num = []

    # 汇总智能体位置
    for i in range(Agent_Num):
        if Agent_Sign[i] == 1:  # 参与者位置汇总
            s[2, :, :] = s[2, :, :] + Agent_Loc[i, :, :]
        if Agent_Sign[i] == 2:  # 补给车位置汇总
            s[3, :, :] = s[3, :, :] + Agent_Loc[i, :, :]
        if Agent_Sign[i] == 3:  # 无人机位置汇总
            s[4, :, :] = s[4, :, :] + Agent_Loc[i, :, :]
            # 记录无人机充电需求
            for ii in range(Row):
                for i_3 in range(Lin):
                    if Agent_Loc[i, ii, i_3] == 1:
                        s[5, ii, i_3] = s[5, ii, i_3] + (0.37 ** (Energy[i] / min_value))
                        break
                else:
                    continue
                break
        if Agent_Sign[i] == 4:  # 通信uav
            s[6, :, :] = s[6, :, :] + Agent_Loc[i, :, :]
            com_num.append(i)

    all_com = com_car_range(Curr_Agents, Curr_Com, ConnectRange, Row, Lin, memory_tasks)

    # 保存当前全局视野，用于后续智能体更新局部视野
    s_Temp = s
    # 将全局矩阵变成横向量
    s = s.flatten()

    # 智能体可执行行为
    avail_action = []
    # 局部观察obs应该包含智能体局部通信范围内的观察、当前智能体所在位置、当前智能体类别
    obs = []
    all_connet = {}
    radius = ConnectRange
    # 每个智能体
    for i in range(Agent_Num):
        agent_id = int(DataNO[i])
        agent = Temp_Train[int(agent_id)]
        #  这里要全改
        # 确定智能体通信范围
        Connet_Range = np.zeros((Row, Lin))
        found = False  # 标志变量

        for ii_Range in range(Row):
            for i_3_Range in range(Lin):
                if Agent_Loc[i, ii_Range, i_3_Range] == 1:  # 找到智能体的位置所在
                    coordinate1 = np.array([ii_Range, i_3_Range])
                    for i_com, com_car in enumerate(Curr_Com):  # 变量名修改以避免与外层 i 冲突
                        com_x = com_car[2]
                        com_y = com_car[3]
                        coordinate3 = np.array([com_x, com_y])
                        dist = distance(coordinate1, coordinate3)

                        if dist <= radius:
                            in_which_com = i_com
                            agent_index = int(agent[0])  # 替换为实际值
                            com_index = int(Curr_Com[in_which_com][0])  # 替换为实际值
                            memory_tasks[agent_index] = np.logical_and(memory_tasks[agent_index] > 0,
                                                                       memory_tasks[com_index] > 0)

                            for x in range(Row):
                                for y in range(Lin):
                                    if all_com[i_com][x][y] == 1:
                                        Connet_Range[x, y] = 1

                            found = True  # 设置标志变量
                            break  # 退出内层循环
                    if found:
                        break  # 退出中间循环
            if found:
                break  # 退出外层循环

        # 智能体可选择行为范围计算过程
        all_connet[int(agent_id)] = Connet_Range
        # temp_avail_action = np.zeros((Row + 1, Lin + 1))
        temp_avail_action = np.zeros((Row, Lin))
        if Agent_Sign[i] == 0:
            # temp_avail_action[Row-1, Lin-1] = 1
            temp_avail_action[Row - 1, Lin - 1] = 1
        else:
            agent_x = -1
            agent_y = -1
            for ii in range(Row):  # 自己所在的位置一定是可到达的
                for i_3 in range(Lin):
                    # 定位到智能体位置
                    if Agent_Loc[i, ii, i_3] == 1:
                        # temp_avail_action[ii, i_3] = 1
                        agent_x = ii
                        agent_y = i_3
                        break
                else:
                    continue
                break

            speed = agent[6]
            coordinate1 = np.array([agent_x, agent_y])
            # 记录不同智能体移动范围
            if Agent_Sign[i] == 1:  # 工人，凡是有任务点的地方，工人均可以到达
                for Dim_Row in range(Row):
                    for Dim_Lin in range(Lin):
                        if Env_start[1, Dim_Row, Dim_Lin] == 1 and Connet_Range[Dim_Row, Dim_Lin] == 1 and Env[
                            1, Dim_Row, Dim_Lin] == 0:
                            memory_tasks[int(agent[0]), Dim_Row, Dim_Lin] = 0
                            continue
                        if memory_tasks[int(agent[0]), Dim_Row, Dim_Lin] == 1:  # 表明该地方的任务点不知道到底完成没
                            # avail_behavior[Dim_Row, Dim_Lin] = 1
                            task_coordinate = np.array([Dim_Row, Dim_Lin])
                            worker_to_task = distance(coordinate1, task_coordinate)
                            if worker_to_task / speed + SysTime <= TimeLimit:
                                temp_avail_action[Dim_Row, Dim_Lin] = 1

                if np.all(temp_avail_action == 0):
                    temp_avail_action[int(agent[2]), int(agent[3])] = 1

            elif Agent_Sign[i] == 2:  # 补给车，凡是有续航点的地方，补给车均可以到达
                for Dim_Row in range(Row):
                    for Dim_Lin in range(Lin):
                        if Env[0, Dim_Row, Dim_Lin] == 1:  # 表明该地方有续航点
                            charge_coordinate = np.array([Dim_Row, Dim_Lin])
                            car_to_charge = distance(coordinate1, charge_coordinate)
                            if car_to_charge / speed + SysTime <= TimeLimit:
                                temp_avail_action[Dim_Row, Dim_Lin] = 1

                if np.all(temp_avail_action == 0):
                    temp_avail_action[int(agent[2]), int(agent[3])] = 1


            elif Agent_Sign[i] == 3:  # 无人机
                # 查看无人机可以到达哪些任务点 (不再考虑电量)
                for Dim_Row in range(Row):
                    for Dim_Lin in range(Lin):
                        if Env_start[1, Dim_Row, Dim_Lin] == 1 and Connet_Range[Dim_Row, Dim_Lin] == 1 and Env[
                            1, Dim_Row, Dim_Lin] == 0:
                            memory_tasks[int(agent[0]), Dim_Row, Dim_Lin] = 0
                            continue
                        if memory_tasks[int(agent[0]), Dim_Row, Dim_Lin] == 1:  # 如果任务点存在
                            task_coordinate = np.array([Dim_Row, Dim_Lin])
                            uav_to_task = distance(coordinate1, task_coordinate)
                            # 只判断移动是否会超时
                            if uav_to_task / speed + SysTime <= TimeLimit:
                                temp_avail_action[Dim_Row, Dim_Lin] = 1
                # 查看无人机可以到达哪些续航点 (不再考虑电量)
                for Dim_Row in range(Row):
                    for Dim_Lin in range(Lin):
                        if Env[0, Dim_Row, Dim_Lin] == 1:  # 如果续航点存在
                            uav_to_charge = distance(coordinate1, np.array([Dim_Row, Dim_Lin]))
                            # 只判断移动是否会超时
                            if uav_to_charge / speed + SysTime <= TimeLimit:
                                temp_avail_action[Dim_Row, Dim_Lin] = 1
                if np.all(temp_avail_action == 0):
                    temp_avail_action[int(agent[2]), int(agent[3])] = 1

            # 不知道啊，我觉得通信无人机哪里都可以去
            elif Agent_Sign[i] == 4:
                for Dim_Row in range(Row):
                    for Dim_Lin in range(Lin):
                        if Env[0, Dim_Row, Dim_Lin] == 1:  # 表明该地方有续航点
                            charge_coordinate = np.array([Dim_Row, Dim_Lin])
                            com_to_charge = distance(coordinate1, charge_coordinate)
                            if com_to_charge / speed + SysTime <= TimeLimit:
                                temp_avail_action[Dim_Row, Dim_Lin] = 1

                if np.all(temp_avail_action == 0):
                    temp_avail_action[int(agent[2]), int(agent[3])] = 1

        # print(temp_avail_action)
        # 将可执行行为范围变成横向量
        temp_avail_action = temp_avail_action.flatten()
        avail_action = np.concatenate((avail_action, temp_avail_action), 0)
        # print(Env[1,:,:].shape)

        # 确定智能体视野范围内的环境信息，并加入智能体局部观察
        Env_Agent = np.zeros((7, Row, Lin))
        Env_Agent[0, :, :] = s_Temp[0, :, :]  # 续航点分布
        Env_Agent[1, :, :] = s_Temp[1, :, :] * Connet_Range[0:Row, 0:Lin]  # 任务点分布
        Env_Agent[2, :, :] = s_Temp[2, :, :] * Connet_Range[0:Row, 0:Lin]  # 参与者位置
        Env_Agent[3, :, :] = s_Temp[3, :, :] * Connet_Range[0:Row, 0:Lin]  # 补给车位置
        Env_Agent[4, :, :] = s_Temp[4, :, :] * Connet_Range[0:Row, 0:Lin]  # 无人机位置
        Env_Agent[5, :, :] = s_Temp[5, :, :] * Connet_Range[0:Row, 0:Lin]  # 无人机电量
        Env_Agent[6, :, :] = s_Temp[6, :, :] * Connet_Range[0:Row, 0:Lin]  # 通信无人机

        Env_Agent = Env_Agent.flatten()
        obs = np.concatenate((obs, Env_Agent), 0)

        # 将该智能体位置信息加入局部观察，用于标识该智能体
        Agent_Loc_Temp = Agent_Loc[i, :, :].flatten()
        obs = np.concatenate((obs, Agent_Loc_Temp), 0)
        if Agent_Sign[i] > 0:
            # 记录当前智能体类别
            if Agent_Sign[i] == 1:
                obs = np.concatenate((obs, [1, 0, 0, 0]), 0)
                obs = np.concatenate((obs, [0]), 0)
            if Agent_Sign[i] == 2:
                obs = np.concatenate((obs, [0, 1, 0, 0]), 0)
                obs = np.concatenate((obs, [0]), 0)
            if Agent_Sign[i] == 3:
                obs = np.concatenate((obs, [0, 0, 1, 0]), 0)
                obs = np.concatenate((obs, [(0.37 ** (Energy[i] / min_value))]), 0)
            if Agent_Sign[i] == 4:
                obs = np.concatenate((obs, [0, 0, 0, 1]), 0)
                obs = np.concatenate((obs, [0]), 0)
        else:
            obs = np.concatenate((obs, [0, 0, 0, 0]), 0)
            obs = np.concatenate((obs, [0]), 0)

    return s, obs, avail_action, all_connet


def com_car_range(Curr_Agents, Curr_Com, ConnectRange, Row, Lin, memory_tasks):
    radius = ConnectRange
    num_com = len(Curr_Com)
    # 1. 先把 each_com_only[i] 填成“只含第 i 辆车自身覆盖”的格子（单车射程）
    each_com_only = [np.zeros((Row, Lin), dtype=int) for _ in range(num_com)]
    for i, car in enumerate(Curr_Com):
        x_i, y_i = car[2], car[3]
        for r in range(Row):
            for c in range(Lin):
                if distance([x_i, y_i], [r, c]) <= radius:
                    each_com_only[i][r, c] = 1

    # 2. 把 all_com 初始设为“车 i 与其所有直接连通邻居”的覆盖（就是你原来的代码）
    all_com = []
    for i, com_car in enumerate(Curr_Com):
        # a. 先把自己盖上
        Connet_Range = each_com_only[i].copy()
        # b. 如果 j 与 i 直接连（中心距 ≤ radius），就把 j 的单车射程也并进来
        for j, other_car in enumerate(Curr_Com):
            if i != j:
                x_i, y_i = com_car[2], com_car[3]
                x_j, y_j = other_car[2], other_car[3]
                if distance([x_i, y_i], [x_j, y_j]) <= radius:
                    Connet_Range |= each_com_only[j]
        all_com.append(Connet_Range)

    changed = True
    while changed:
        changed = False
        for i in range(num_com):
            # 看看哪些车 j，i 的 current_cover 能“看到”j 的中心
            # （只要 all_com[i][x_j, y_j] == True，就说明 i 通过某条链能间接或直接连到 j）
            for j in range(num_com):
                if i != j:
                    x_j, y_j = Curr_Com[j][2], Curr_Com[j][3]
                    if all_com[i][int(x_j), int(y_j)] == 1:
                        # i 已经可以“看到”j，那么直接把 j 的当前合并覆盖并进来
                        before = copy.deepcopy(all_com[i])
                        all_com[i] |= all_com[j]
                        # 如果有新的格子被加进来，就标记一次 change
                        if not np.array_equal(before, all_com[i]):
                            changed = True

    unique_ranges = []  # 用来收每个独立通信范围“代表”所对应的覆盖布尔矩阵
    for i in range(num_com):
        mat = all_com[i]
        # 看看 mat 是否已经在 unique_ranges 里有了“克隆版”
        found = False
        for u in unique_ranges:
            if np.array_equal(u, mat):
                found = True
                break
        if not found:
            unique_ranges.append(mat)
    num_independent_ranges = len(unique_ranges)
    # print(f"最终真实的独立通信范围数量：{num_independent_ranges}")

    unique_memories = []
    for unique_range in unique_ranges:
        unique_memory = np.ones((Row, Lin), dtype=int)
        for agent in Curr_Agents:
            # 只更新 通信车 的记录
            if agent[5] != 4:
                continue
            if unique_range[int(agent[2]), int(agent[3])] == 1:  # 在通信范围内
                # 逐元素与：只有当所有范围内 agent 的 memory_tasks 都为 1 时，unique_memory 才保留 1
                unique_memory = unique_memory * memory_tasks[int(agent[0])]
        unique_memories.append(unique_memory)

    for i, unique_range in enumerate(unique_ranges):
        for agent in Curr_Agents:
            # 只更新 通信车 的记录
            if agent[5] != 4:
                continue
            if unique_range[int(agent[2]), int(agent[3])] == 1:  # 在通信范围内
                memory_tasks[int(agent[0])] = unique_memories[i]

    return all_com


# 新增参数 total_recharged_energy 用于累计充电量
def Update_Agent_Loc(Env, Agent_Sign, Energy, PowerConsum, action, Agent_Loc_, Energy_FULL, Task_Time, memory_tasks,
                     all_connet, DataNO, Temp_Train, total_recharged_energy):
    # 更新智能体位置
    Row = Env.shape[1]
    Lin = Env.shape[2]
    # 获取智能体数量
    Agent_Num = Agent_Sign.shape[0]
    # 初始化各个智能体位置
    Agent_Loc = np.zeros((Agent_Num, Row, Lin))
    # 计算各个智能体时间花费
    DelatTime = np.zeros((Agent_Num))

    # 更新各个智能体位置
    for Agent_Index in range(Agent_Num):
        if Agent_Sign[Agent_Index] > 0:
            Agent_Row = int(action[Agent_Index] / (Lin))
            Agent_Lin = int(action[Agent_Index] % (Lin))
            Agent_Loc[Agent_Index, Agent_Row, Agent_Lin] = 1
            # 找到智能体原本所在位置，然后计算原位置到新位置的旅行距离
            for ii in range(Row):  # 找到智能体原本所在位置
                for i_3 in range(Lin):
                    # 定位到智能体位置
                    if Agent_Loc_[Agent_Index, ii, i_3] == 1:
                        DisCount = math.sqrt((ii - Agent_Row) ** 2 + (i_3 - Agent_Lin) ** 2)
                        DelatTime[Agent_Index] = math.ceil(DisCount / PowerConsum[Agent_Index])
                        break
                else:
                    continue
                break

    # 更新环境中的任务信息和奖励
    # 初始化奖励
    Task_r = 0
    Energy_r = 0
    for i in range(Row):
        for ii in range(Lin):
            # 计算目标区域各种智能体的数量
            User_Num = 0
            Car_Num = 0
            UAV_Num = 0
            Com_Num = 0  # 通信无人机数量
            for Agent_Index in range(Agent_Num):
                # 统计该位置参与者数量
                if Agent_Loc[Agent_Index, i, ii] == 1 and Agent_Sign[Agent_Index] == 1:
                    User_Num = User_Num + 1
                # 统计该位置补给车数量
                if Agent_Loc[Agent_Index, i, ii] == 1 and Agent_Sign[Agent_Index] == 2:
                    Car_Num = Car_Num + 1
                # 统计该位置能工作的无人机数量
                if Agent_Loc[Agent_Index, i, ii] == 1 and Agent_Sign[Agent_Index] == 3:
                    UAV_Num = UAV_Num + 1
                # ----------增加通信无人机
                if Agent_Loc[Agent_Index, i, ii] == 1 and Agent_Sign[Agent_Index] == 4:
                    Com_Num = Com_Num + 1

            # 有任务就做，没任务就拉倒
            if Env[1, i, ii] == 1 and User_Num > 0 and UAV_Num > 0:
                Env[1, i, ii] = 0
                # 以单时间步长完成的任务数作为奖励
                Task_r = Task_r + 1

                # 更新工人和无人机的时间，最早到达的无人机和工人执行任务
                Time = np.ones((2, 2)) * 10000

                for Index in range(Agent_Num):
                    # 当前位置有工人
                    if Agent_Loc[Index, i, ii] == 1 and Agent_Sign[Index] == 1:
                        if Time[0, 0] > DelatTime[Index]:
                            Time[0, 0] = np.copy(DelatTime[Index])
                            Time[0, 1] = np.copy(Index)
                    # 当前位置有无人机
                    if Agent_Loc[Index, i, ii] == 1 and Agent_Sign[Index] == 3:
                        if Time[1, 0] > DelatTime[Index]:
                            Time[1, 0] = np.copy(DelatTime[Index])
                            Time[1, 1] = np.copy(Index)
                DelatTime[int(Time[0, 1])] = DelatTime[int(Time[0, 1])] + math.ceil(
                    Task_Time[i, ii] / PowerConsum[int(Time[1, 1])])
                DelatTime[int(Time[1, 1])] = DelatTime[int(Time[1, 1])] + math.ceil(
                    Task_Time[i, ii] / PowerConsum[int(Time[1, 1])])

                # 执行任务时，后者必须等到前者到达后才能开始
                if DelatTime[int(Time[0, 1])] > DelatTime[int(Time[1, 1])]:
                    DelatTime[int(Time[1, 1])] = DelatTime[int(Time[0, 1])]
                else:
                    DelatTime[int(Time[0, 1])] = DelatTime[int(Time[1, 1])]

                worker_id = int(Time[0, 1])
                uav_id = int(Time[1, 1])
                # print("DataNO:", DataNO)
                # print("worker_id:", worker_id)
                # print("DataNO[worker_id]:", DataNO[worker_id])

                agent_worker = Temp_Train[int(DataNO[worker_id])]
                agent_uav = Temp_Train[int(DataNO[uav_id])]
                # 无人机执行完任务的消耗
                Energy[int(Time[1, 1])] = Energy[int(Time[1, 1])] - Task_Time[i, ii]
                # Task_Time[i,ii] = 0

                ## 更新memory_tasks
                for Agent_Index in range(Agent_Num):
                    if Agent_Sign[Agent_Index] <= 0:
                        continue
                    Temp_id = int(DataNO[Agent_Index])
                    agent = Temp_Train[Temp_id]
                    # print("Temp_id:",Temp_id)
                    # print("all_connet.keys()",all_connet.keys())
                    # print("agent:",agent)
                    # print("DataNO:",DataNO)
                    connet = all_connet[Temp_id]
                    # 能和执行任务的工人和无人机通信，才算知道这个任务是能够被完成的
                    if connet[int(agent_worker[2]), int(agent_worker[3])] > 0 and connet[
                        int(agent_uav[2]), int(agent_uav[3])] > 0:
                        memory_tasks[int(agent[0])][i][ii] = 0

            # 查看该地是否有补给小车，有的话就查看是否有无人机更换电池
            if Env[0, i, ii] == 1 and Car_Num > 0 and UAV_Num > 0:
                # 允许车辆同时给多个无人机同时充电，车辆在续航点待到最后一架无人机充电完成为止
                # 如果无人机到达续航点的时候，发现该续航点同时存在多个车辆，无人机选择在先到的车辆上充电，先到车辆负责该所有无人机充电
                Time_Energy = np.ones((1, 2)) * 10000
                for Car_Index in range(Agent_Num):  # 确定充电车辆
                    # 当前位置有车辆 找个最近的车
                    if Agent_Loc[Car_Index, i, ii] == 1 and Agent_Sign[Car_Index] == 2:
                        if Time_Energy[0, 0] > DelatTime[Car_Index]:
                            Time_Energy[0, 0] = np.copy(DelatTime[Car_Index])
                            Time_Energy[0, 1] = np.copy(Car_Index)
                ### 这里我们设定为可以同时充电
                car_time = DelatTime[int(Time_Energy[0, 1])]
                for UAV_Index in range(Agent_Num):  # 给无人机充电
                    # 当前位置有无人机
                    if Agent_Loc[UAV_Index, i, ii] == 1 and Agent_Sign[UAV_Index] == 3:
                        # 这是 计算充电的时间？ （需要的电量 ）/
                        DeTime = math.ceil(
                            (Energy_FULL[UAV_Index] - Energy[UAV_Index]) / Energy_FULL[int(Time_Energy[0, 1])])

                        start = max(car_time, DelatTime[UAV_Index])
                        # 无人机和车辆必须都等到双方到了才能进行充电服务
                        DelatTime[UAV_Index] = start + DeTime

                        # 新增：在充电前，计算并累加本次补充的电量
                        recharged_amount = Energy_FULL[UAV_Index] - Energy[UAV_Index]
                        if recharged_amount > 0:  # 确保只累加正的充电量
                            total_recharged_energy += recharged_amount

                        # 无人机充电完成
                        Energy[UAV_Index] = Energy_FULL[UAV_Index]

                        # 车辆需要时间是最后一辆充完电的无人机用时
                        if DelatTime[int(Time_Energy[0, 1])] < DelatTime[UAV_Index]:
                            DelatTime[int(Time_Energy[0, 1])] = DelatTime[UAV_Index]

                        # Energy_r = Energy_r + ((0.37 ** int(Energy[UAV_Index] / PowerConsum[UAV_Index])) - (
                        #             0.37 ** int(100 / PowerConsum[UAV_Index])))
                        Energy_r = Energy_r + ((0.37 ** int(Energy[UAV_Index] / PowerConsum[UAV_Index])) - (
                                0.37 ** int(Energy_FULL[UAV_Index] / PowerConsum[UAV_Index])))
    # print(Agent_Sign)
    # print(DelatTime)
    # print(Energy)
    # print('***********************************************')
    # 计算复合奖励
    r = Task_r + Energy_r
    # 返回值中增加 total_recharged_energy
    return Env, Agent_Loc, Energy, r, DelatTime, total_recharged_energy